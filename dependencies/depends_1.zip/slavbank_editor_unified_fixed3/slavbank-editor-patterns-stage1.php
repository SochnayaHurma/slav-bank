<?php
/**
 * Plugin Name: Slavyanbank Editor Patterns Stage 1.8
 * Description: Stage 1.8 Gutenberg companion plugin for Slavyanbank theme audit. Adds ready-made page and section patterns built from the existing Slavyanbank editor blocks so pages can be assembled faster without touching live templates.
 * Version: 0.8.0
 * Author: OpenAI
 */

if (!defined('ABSPATH')) {
    exit;
}

final class Slavyanbank_Editor_Patterns_Stage1_8 {
    private const CATEGORY = 'slavyanbank-page-patterns';

    public static function init(): void {
        add_action('init', [self::class, 'register_pattern_category'], 20);
        add_action('init', [self::class, 'register_patterns'], 20);
    }

    public static function register_pattern_category(): void {
        if (!function_exists('register_block_pattern_category')) {
            return;
        }

        register_block_pattern_category(self::CATEGORY, [
            'label' => 'Slavyanbank Pages',
        ]);
    }

    public static function register_patterns(): void {
        if (!function_exists('register_block_pattern')) {
            return;
        }

        $registry = WP_Block_Type_Registry::get_instance();
        if (!$registry->is_registered('slavyanbank-stage1/section-shell')) {
            return;
        }

        $patterns = [
            'reporting-page'   => ['title' => 'SB Reporting Page Scaffold', 'description' => 'Стартовый каркас страницы Отчетность.', 'content' => self::reporting_pattern()],
            'info-bank-page'   => ['title' => 'SB Info Bank Page Scaffold', 'description' => 'Стартовый каркас страницы Информация банка.', 'content' => self::info_bank_pattern()],
            'requisites-page'  => ['title' => 'SB Requisites Page Scaffold', 'description' => 'Стартовый каркас страницы Реквизиты банка.', 'content' => self::requisites_pattern()],
            'contacts-page'    => ['title' => 'SB Contacts Page Scaffold', 'description' => 'Стартовый каркас страницы Контакты.', 'content' => self::contacts_pattern()],
            'support-page'     => ['title' => 'SB Support Page Scaffold', 'description' => 'Стартовый каркас страницы Поддержка.', 'content' => self::support_pattern()],
            'tariffs-page'     => ['title' => 'SB Tariffs Page Scaffold', 'description' => 'Стартовый каркас страницы Тарифы банка.', 'content' => self::tariffs_pattern()],
        ];

        foreach ($patterns as $slug => $pattern) {
            register_block_pattern('slavyanbank-stage1/' . $slug, [
                'title'       => $pattern['title'],
                'description' => $pattern['description'],
                'categories'  => [self::CATEGORY],
                'content'     => $pattern['content'],
            ]);
        }
    }

    private static function reporting_pattern(): string {
        return <<<'HTML'
<!-- wp:slavyanbank-stage1/section-shell -->
<section class="block"><div class="container">
<!-- wp:slavyanbank-stage1/hero-shell {"kicker":"Информация банка","title":"Отчетность","text":"Бухгалтерская (финансовая) отчетность раскрывается в ограниченном объёме в соответствии с текущими требованиями.","actions":[{"text":"Содержание","url":"#content","variant":"primary","newTab":false},{"text":"На главную","url":"/","variant":"outline","newTab":false}],"metaItems":[{"text":"Реквизиты","url":"/rekvizity-banka/","kind":"badge","newTab":false},{"text":"·","url":"","kind":"muted","newTab":false},{"text":"Информация банка","url":"/informaciya-banka/","kind":"badge","newTab":false}]} /-->
</div></section>
<!-- /wp:slavyanbank-stage1/section-shell -->

<!-- wp:slavyanbank-stage1/section-shell {"variant":"dashv2","anchor":"content"} -->
<section class="block dashv2" id="content"><div class="container">
<!-- wp:slavyanbank-stage1/bento-layout -->
<div class="bento">
<!-- wp:slavyanbank-stage1/bento-card-shell -->
<div class="bento-card" style="padding:var(--s-4);position:relative">
<!-- wp:core/heading {"level":3,"className":"kicker"} -->
<h3 class="wp-block-heading kicker">ОТЧЕТНОСТЬ АО НКБ «СЛАВЯНБАНК»</h3>
<!-- /wp:core/heading -->

<!-- wp:core/paragraph {"align":"center"} -->
<p class="has-text-align-center"><strong>ГОДОВАЯ БУХГАЛТЕРСКАЯ (ФИНАНСОВАЯ) ОТЧЕТНОСТЬ</strong></p>
<!-- /wp:core/paragraph -->

<!-- wp:slavyanbank-stage1/document-shelf /-->
<!-- wp:slavyanbank-stage1/prose-shell -->
<div class="prose"><div class="entry-content">
<!-- wp:slavyanbank-stage1/reporting-accordion /-->
</div></div>
<!-- /wp:slavyanbank-stage1/prose-shell -->
</div>
<!-- /wp:slavyanbank-stage1/bento-card-shell -->

<!-- wp:slavyanbank-stage1/stack-shell -->
<div class="stack">
<!-- wp:slavyanbank-stage1/home-stack /-->
</div>
<!-- /wp:slavyanbank-stage1/stack-shell -->
</div>
<!-- /wp:slavyanbank-stage1/bento-layout -->
</div></section>
<!-- /wp:slavyanbank-stage1/section-shell -->
HTML;
    }

    private static function info_bank_pattern(): string {
        return <<<'HTML'
<!-- wp:slavyanbank-stage1/section-shell {"variant":"dashv2","anchor":"info-bank"} -->
<section class="block dashv2" id="info-bank"><div class="container">
<!-- wp:slavyanbank-stage1/bento-layout -->
<div class="bento">
<!-- wp:slavyanbank-stage1/bento-card-shell -->
<div class="bento-card" style="padding:var(--s-4);position:relative">
<!-- wp:slavyanbank-stage1/document-tabs /-->
</div>
<!-- /wp:slavyanbank-stage1/bento-card-shell -->

<!-- wp:slavyanbank-stage1/stack-shell -->
<div class="stack">
<!-- wp:slavyanbank-stage1/home-stack /-->
</div>
<!-- /wp:slavyanbank-stage1/stack-shell -->
</div>
<!-- /wp:slavyanbank-stage1/bento-layout -->
</div></section>
<!-- /wp:slavyanbank-stage1/section-shell -->
HTML;
    }

    private static function requisites_pattern(): string {
        return <<<'HTML'
<!-- wp:slavyanbank-stage1/section-shell -->
<section class="block"><div class="container">
<!-- wp:slavyanbank-stage1/hero-shell {"kicker":"О банке","title":"Реквизиты банка","text":"Основные реквизиты, контакты и справочная информация для клиентов и контрагентов.","actions":[{"text":"Информация о представителях","url":"#key","variant":"primary","newTab":false},{"text":"Перейти к реквизитам","url":"#full","variant":"outline","newTab":false}],"metaItems":[{"text":"Контакты","url":"","kind":"badge","newTab":false},{"text":"(8162) 66‑52‑47","url":"tel:+78162665247","kind":"mono","newTab":false},{"text":"·","url":"","kind":"muted","newTab":false},{"text":"nkb@slavbank.ru","url":"mailto:nkb@slavbank.ru","kind":"default","newTab":false}]} /-->
</div></section>
<!-- /wp:slavyanbank-stage1/section-shell -->

<!-- wp:slavyanbank-stage1/section-shell {"variant":"dashv2","anchor":"key"} -->
<section class="block dashv2" id="key"><div class="container">
<!-- wp:slavyanbank-stage1/bento-layout -->
<div class="bento">
<!-- wp:slavyanbank-stage1/bento-card-shell -->
<div class="bento-card" style="padding:var(--s-4);position:relative">
<!-- wp:slavyanbank-stage1/alert {"title":"Справочная информация","text":"Здесь можно разместить аудитора, регистратора, банковский надзор и другие сопровождающие блоки перед таблицей реквизитов."} /-->
<!-- wp:slavyanbank-stage1/prose-shell -->
<div class="prose"><div class="entry-content">
<!-- wp:core/paragraph -->
<p>Добавьте или отредактируйте сопровождающий текст для страницы реквизитов, сохранив текущий визуальный язык темы.</p>
<!-- /wp:core/paragraph -->
</div></div>
<!-- /wp:slavyanbank-stage1/prose-shell -->
</div>
<!-- /wp:slavyanbank-stage1/bento-card-shell -->

<!-- wp:slavyanbank-stage1/stack-shell -->
<div class="stack">
<!-- wp:slavyanbank-stage1/home-stack /-->
</div>
<!-- /wp:slavyanbank-stage1/stack-shell -->
</div>
<!-- /wp:slavyanbank-stage1/bento-layout -->
</div></section>
<!-- /wp:slavyanbank-stage1/section-shell -->

<!-- wp:slavyanbank-stage1/section-shell {"anchor":"full"} -->
<section class="block" id="full"><div class="container">
<!-- wp:slavyanbank-stage1/requisites-table /-->
</div></section>
<!-- /wp:slavyanbank-stage1/section-shell -->
HTML;
    }

    private static function contacts_pattern(): string {
        return <<<'HTML'
<!-- wp:slavyanbank-stage1/section-shell -->
<section class="block"><div class="container">
<!-- wp:slavyanbank-stage1/hero-shell {"kicker":"Раздел","title":"Контакты","text":"Как связаться с банком: телефон, электронная почта, адрес и режим работы.","actions":[{"text":"Написать в банк","url":"/napisat-v-bank/#form","variant":"outline","newTab":false},{"text":"Поддержка","url":"/podderzhka/","variant":"outline","newTab":false},{"text":"На главную","url":"/","variant":"glass","newTab":false}],"metaItems":[]} /-->
</div></section>
<!-- /wp:slavyanbank-stage1/section-shell -->

<!-- wp:slavyanbank-stage1/section-shell {"variant":"dashv2","anchor":"content"} -->
<section class="block dashv2" id="content"><div class="container">
<!-- wp:slavyanbank-stage1/bento-layout -->
<div class="bento">
<!-- wp:slavyanbank-stage1/bento-card-shell -->
<div class="bento-card" style="padding:var(--s-4);position:relative">
<!-- wp:slavyanbank-stage1/alert {"title":"Контакты банка","text":"Ниже — основные каналы связи, адрес и режим работы. Для обращений используйте форму «Написать в банк»."} /-->
<!-- wp:slavyanbank-stage1/contact-channels /-->
<!-- wp:slavyanbank-stage1/contact-route-actions /-->
</div>
<!-- /wp:slavyanbank-stage1/bento-card-shell -->

<!-- wp:slavyanbank-stage1/stack-shell -->
<div class="stack">
<!-- wp:slavyanbank-stage1/home-stack /-->
</div>
<!-- /wp:slavyanbank-stage1/stack-shell -->
</div>
<!-- /wp:slavyanbank-stage1/bento-layout -->
</div></section>
<!-- /wp:slavyanbank-stage1/section-shell -->
HTML;
    }

    private static function support_pattern(): string {
        return <<<'HTML'
<!-- wp:slavyanbank-stage1/section-shell -->
<section class="block"><div class="container">
<!-- wp:slavyanbank-stage1/hero-shell {"kicker":"Раздел","title":"Поддержка","text":"Часто задаваемые вопросы — ответы на вопросы, возникающие при работе в системе Клиент-Банк.","actions":[{"text":"Содержание","url":"#content","variant":"primary","newTab":false},{"text":"На главную","url":"/","variant":"outline","newTab":false}],"metaItems":[{"text":"Безопасность","url":"/security/","kind":"badge","newTab":false},{"text":"·","url":"","kind":"muted","newTab":false},{"text":"Клиент‑Банк","url":"/client-bank-online/","kind":"badge","newTab":false},{"text":"·","url":"","kind":"muted","newTab":false},{"text":"123‑ФЗ","url":"/appeal-123-fz/","kind":"badge","newTab":false}]} /-->
</div></section>
<!-- /wp:slavyanbank-stage1/section-shell -->

<!-- wp:slavyanbank-stage1/section-shell {"variant":"dashv2","anchor":"content"} -->
<section class="block dashv2" id="content"><div class="container">
<!-- wp:slavyanbank-stage1/bento-layout -->
<div class="bento">
<!-- wp:slavyanbank-stage1/bento-card-shell -->
<div class="bento-card" style="padding:var(--s-4);position:relative">
<!-- wp:slavyanbank-stage1/support-topics-grid /-->
<!-- wp:slavyanbank-stage1/service-links /-->
</div>
<!-- /wp:slavyanbank-stage1/bento-card-shell -->

<!-- wp:slavyanbank-stage1/stack-shell -->
<div class="stack">
<!-- wp:slavyanbank-stage1/home-stack /-->
</div>
<!-- /wp:slavyanbank-stage1/stack-shell -->
</div>
<!-- /wp:slavyanbank-stage1/bento-layout -->
</div></section>
<!-- /wp:slavyanbank-stage1/section-shell -->
HTML;
    }

    private static function tariffs_pattern(): string {
        return <<<'HTML'
<!-- wp:slavyanbank-stage1/section-shell -->
<section class="block"><div class="container">
<!-- wp:slavyanbank-stage1/hero-shell {"kicker":"Раздел","title":"Тарифы банка","text":"Текущие тарифные предложения и ссылки на скачивание или просмотр тарифных материалов.","actions":[{"text":"Перейти к содержимому","url":"#pdf","variant":"primary","newTab":false},{"text":"На главную","url":"/","variant":"outline","newTab":false}],"metaItems":[]} /-->
</div></section>
<!-- /wp:slavyanbank-stage1/section-shell -->

<!-- wp:slavyanbank-stage1/section-shell {"variant":"dashv2","anchor":"pdf"} -->
<section class="block dashv2" id="pdf"><div class="container">
<!-- wp:slavyanbank-stage1/bento-layout -->
<div class="bento">
<!-- wp:slavyanbank-stage1/bento-card-shell -->
<div class="bento-card" style="padding:var(--s-4);position:relative">
<!-- wp:slavyanbank-stage1/prose-shell -->
<div class="prose"><div class="entry-content">
<!-- wp:core/heading {"level":3,"className":"kicker"} -->
<h3 class="wp-block-heading kicker">Тарифы банка</h3>
<!-- /wp:core/heading -->
<!-- wp:core/paragraph -->
<p><strong>— скачать:</strong></p>
<!-- /wp:core/paragraph -->
<!-- wp:slavyanbank-stage1/tariff-card-list /-->
<!-- wp:core/paragraph -->
<p><strong>— открыть на сайте:</strong></p>
<!-- /wp:core/paragraph -->
<!-- wp:slavyanbank-stage1/tariff-card-list /-->
</div></div>
<!-- /wp:slavyanbank-stage1/prose-shell -->
</div>
<!-- /wp:slavyanbank-stage1/bento-card-shell -->

<!-- wp:slavyanbank-stage1/stack-shell -->
<div class="stack">
<!-- wp:slavyanbank-stage1/home-stack /-->
</div>
<!-- /wp:slavyanbank-stage1/stack-shell -->
</div>
<!-- /wp:slavyanbank-stage1/bento-layout -->
</div></section>
<!-- /wp:slavyanbank-stage1/section-shell -->
HTML;
    }
}

Slavyanbank_Editor_Patterns_Stage1_8::init();
