<?php
/**
 * Plugin Name: Slavyanbank Editor Blocks Grouped Stage 1.7
 * Description: Stage 1.7 Gutenberg blocks for Slavyanbank theme audit. Adds editor layout/container blocks using existing theme classes so pages can be assembled from reusable blocks without new CSS.
 * Version: 0.9.0
 * Author: OpenAI
 */

if (!defined('ABSPATH')) {
    exit;
}

final class Slavyanbank_Editor_Blocks_Grouped_Stage1_7 {
    private const CATEGORY = 'slavyanbank-stage1';
    private const SCRIPT_COMMON = 'sbeb-stage1-common';
    private const SCRIPT_HERO = 'sbeb-stage1-hero';
    private const SCRIPT_DOCS = 'sbeb-stage1-docs';
    private const SCRIPT_REQUISITES = 'sbeb-stage1-requisites';
    private const SCRIPT_SUPPORT = 'sbeb-stage1-support';
    private const SCRIPT_REPORTING = 'sbeb-stage1-reporting';
    private const SCRIPT_HOME = 'sbeb-stage1-home';
    private const SCRIPT_CONTACTS = 'sbeb-stage1-contacts';
    private const SCRIPT_LAYOUT = 'sbeb-stage1-layout';

    /** @var string[] */
    private static array $shared_style_handles = [];

    public static function init(): void {
        add_action('init', [self::class, 'register_assets']);
        add_action('init', [self::class, 'register_blocks']);
        add_action('enqueue_block_editor_assets', [self::class, 'enqueue_editor_theme_styles']);
        add_filter('block_categories_all', [self::class, 'register_category'], 10, 2);
    }

    public static function register_category(array $categories, $post): array {
        foreach ($categories as $category) {
            if (($category['slug'] ?? '') === self::CATEGORY) {
                return $categories;
            }
        }

        $categories[] = [
            'slug'  => self::CATEGORY,
            'title' => 'Slavyanbank',
            'icon'  => 'bank',
        ];

        return $categories;
    }

    public static function register_assets(): void {
        $base_url = plugin_dir_url(__FILE__);
        $base_dir = plugin_dir_path(__FILE__);

        self::register_theme_style_handles();

        $common_deps = [
            'wp-blocks',
            'wp-element',
            'wp-components',
            'wp-block-editor',
            'wp-i18n',
            'wp-server-side-render',
        ];

        wp_register_script(
            self::SCRIPT_COMMON,
            $base_url . 'assets/js/blocks-common.js',
            $common_deps,
            (string) filemtime($base_dir . 'assets/js/blocks-common.js'),
            true
        );

        wp_localize_script(
            self::SCRIPT_COMMON,
            'SBEB_STAGE1_CONFIG',
            [
                'category' => self::CATEGORY,
            ]
        );

        self::register_group_script(self::SCRIPT_HERO, 'assets/js/blocks-hero.js');
        self::register_group_script(self::SCRIPT_DOCS, 'assets/js/blocks-docs.js');
        self::register_group_script(self::SCRIPT_REQUISITES, 'assets/js/blocks-requisites.js');
        self::register_group_script(self::SCRIPT_SUPPORT, 'assets/js/blocks-support.js');
        self::register_group_script(self::SCRIPT_REPORTING, 'assets/js/blocks-reporting.js');
        self::register_group_script(self::SCRIPT_HOME, 'assets/js/blocks-home.js');
        self::register_group_script(self::SCRIPT_CONTACTS, 'assets/js/blocks-contacts.js');
        self::register_group_script(self::SCRIPT_LAYOUT, 'assets/js/blocks-layout.js');
    }

    private static function register_group_script(string $handle, string $relative_path): void {
        $base_url = plugin_dir_url(__FILE__);
        $base_dir = plugin_dir_path(__FILE__);
        $absolute = $base_dir . $relative_path;

        wp_register_script(
            $handle,
            $base_url . $relative_path,
            [self::SCRIPT_COMMON],
            (string) filemtime($absolute),
            true
        );
    }

    private static function register_theme_style_handles(): void {
        $files = [
            'style.css',
            'assets/css/tokens.css',
            'assets/css/motion.css',
            'assets/css/layout.css',
        ];

        self::$shared_style_handles = [];

        foreach ($files as $index => $relative_path) {
            $absolute = get_theme_file_path($relative_path);
            $uri = get_theme_file_uri($relative_path);

            if (!is_string($absolute) || $absolute === '' || !file_exists($absolute)) {
                continue;
            }

            $handle = 'sbeb-stage1-theme-style-' . $index;
            wp_register_style(
                $handle,
                $uri,
                [],
                (string) filemtime($absolute)
            );

            self::$shared_style_handles[] = $handle;
        }
    }

    public static function enqueue_editor_theme_styles(): void {
        foreach (self::$shared_style_handles as $handle) {
            wp_enqueue_style($handle);
        }
    }

    private static function shared_block_args(array $args, string $script_handle): array {
        $styles = self::$shared_style_handles;

        $base = [
            'api_version'   => 2,
            'editor_script' => $script_handle,
        ];

        if (!empty($styles)) {
            $base['style'] = $styles;
            $base['editor_style'] = $styles;
        }

        return array_merge($base, $args);
    }

    public static function register_blocks(): void {
        register_block_type('slavyanbank-stage1/alert', self::shared_block_args([
            'attributes' => [
                'title' => ['type' => 'string', 'default' => 'Контакты банка'],
                'text'  => ['type' => 'string', 'default' => 'Ниже — основные каналы связи, адрес и режим работы.'],
            ],
            'render_callback' => [self::class, 'render_alert'],
        ], self::SCRIPT_HERO));

        register_block_type('slavyanbank-stage1/hero-shell', self::shared_block_args([
            'attributes' => [
                'kicker'              => ['type' => 'string', 'default' => 'Информация банка'],
                'title'               => ['type' => 'string', 'default' => 'Отчетность'],
                'text'                => ['type' => 'string', 'default' => 'Бухгалтерская (финансовая) отчетность раскрывается в ограниченном объёме.'],
                'actions'             => ['type' => 'array', 'default' => self::default_hero_actions()],
                'metaItems'           => ['type' => 'array', 'default' => self::default_hero_meta_items()],
                'primaryButtonText'   => ['type' => 'string', 'default' => 'Содержание'],
                'primaryButtonUrl'    => ['type' => 'string', 'default' => '#content'],
                'secondaryButtonText' => ['type' => 'string', 'default' => 'На главную'],
                'secondaryButtonUrl'  => ['type' => 'string', 'default' => '/'],
                'badge1Text'          => ['type' => 'string', 'default' => 'Реквизиты'],
                'badge1Url'           => ['type' => 'string', 'default' => '/rekvizity-banka/'],
                'badge2Text'          => ['type' => 'string', 'default' => 'Информация банка'],
                'badge2Url'           => ['type' => 'string', 'default' => '/informaciya-banka/'],
            ],
            'render_callback' => [self::class, 'render_hero_shell'],
        ], self::SCRIPT_HERO));

        register_block_type('slavyanbank-stage1/document-shelf', self::shared_block_args([
            'attributes' => [
                'items' => [
                    'type' => 'array',
                    'default' => self::default_document_shelf_items(),
                ],
            ],
            'render_callback' => [self::class, 'render_document_shelf'],
        ], self::SCRIPT_DOCS));

        register_block_type('slavyanbank-stage1/document-rows', self::shared_block_args([
            'attributes' => [
                'items' => [
                    'type' => 'array',
                    'default' => self::default_document_rows_items(),
                ],
            ],
            'render_callback' => [self::class, 'render_document_rows'],
        ], self::SCRIPT_DOCS));

        register_block_type('slavyanbank-stage1/document-hero', self::shared_block_args([
            'attributes' => [
                'title'    => ['type' => 'string', 'default' => 'Список лиц, под контролем или значительным влиянием которых находится банк'],
                'subtitle' => ['type' => 'string', 'default' => 'Скачать PDF'],
                'url'      => ['type' => 'string', 'default' => 'https://slavbank.ru/wp-content/uploads/2021/03/spisok250320.pdf'],
                'newTab'   => ['type' => 'boolean', 'default' => true],
            ],
            'render_callback' => [self::class, 'render_document_hero'],
        ], self::SCRIPT_DOCS));

        register_block_type('slavyanbank-stage1/tariff-card-list', self::shared_block_args([
            'attributes' => [
                'items' => [
                    'type' => 'array',
                    'default' => self::default_tariff_items(),
                ],
            ],
            'render_callback' => [self::class, 'render_tariff_card_list'],
        ], self::SCRIPT_DOCS));

        register_block_type('slavyanbank-stage1/document-tabs', self::shared_block_args([
            'attributes' => [
                'ariaLabel' => ['type' => 'string', 'default' => 'Документы банка'],
                'activeTab' => ['type' => 'string', 'default' => 'aff'],
                'tabs' => [
                    'type' => 'array',
                    'default' => self::default_document_tabs_items(),
                ],
            ],
            'render_callback' => [self::class, 'render_document_tabs'],
        ], self::SCRIPT_DOCS));

        register_block_type('slavyanbank-stage1/requisites-table', self::shared_block_args([
            'attributes' => [
                'items' => [
                    'type' => 'array',
                    'default' => self::default_requisites_items(),
                ],
            ],
            'render_callback' => [self::class, 'render_requisites_table'],
        ], self::SCRIPT_REQUISITES));

        register_block_type('slavyanbank-stage1/support-topics-grid', self::shared_block_args([
            'attributes' => [
                'items' => [
                    'type' => 'array',
                    'default' => self::default_support_topics_items(),
                ],
            ],
            'render_callback' => [self::class, 'render_support_topics_grid'],
        ], self::SCRIPT_SUPPORT));

        register_block_type('slavyanbank-stage1/service-links', self::shared_block_args([
            'attributes' => [
                'items' => [
                    'type' => 'array',
                    'default' => self::default_service_links_items(),
                ],
            ],
            'render_callback' => [self::class, 'render_service_links'],
        ], self::SCRIPT_SUPPORT));

        register_block_type('slavyanbank-stage1/reporting-accordion', self::shared_block_args([
            'attributes' => [
                'title' => ['type' => 'string', 'default' => 'ПРОМЕЖУТОЧНАЯ БУХГАЛТЕРСКАЯ (ФИНАНСОВАЯ) ОТЧЕТНОСТЬ,'],
                'subtitle' => ['type' => 'string', 'default' => 'ПОКАЗАТЕЛИ ДЕЯТЕЛЬНОСТИ БАНКА'],
                'sections' => [
                    'type' => 'array',
                    'default' => self::default_reporting_sections(),
                ],
            ],
            'render_callback' => [self::class, 'render_reporting_accordion'],
        ], self::SCRIPT_REPORTING));


        register_block_type('slavyanbank-stage1/home-stack', self::shared_block_args([
            'attributes' => [
                'currencyTitle' => ['type' => 'string', 'default' => 'Курсы валют'],
                'dateLine' => ['type' => 'string', 'default' => 'Данные на текущую дату'],
                'legendTitle' => ['type' => 'string', 'default' => 'Наличные'],
                'buyLabel' => ['type' => 'string', 'default' => 'Покупка'],
                'sellLabel' => ['type' => 'string', 'default' => 'Продажа'],
                'footerText' => ['type' => 'string', 'default' => 'Информация носит справочный характер.'],
                'rates' => ['type' => 'array', 'default' => self::default_home_stack_rates()],
                'publicationsTitle' => ['type' => 'string', 'default' => 'Последние публикации'],
                'publicationsKicker' => ['type' => 'string', 'default' => 'Полезная информация'],
                'publications' => ['type' => 'array', 'default' => self::default_home_stack_publications()],
                'sectionsTitle' => ['type' => 'string', 'default' => 'Разделы сайта'],
                'sectionsOpen' => ['type' => 'boolean', 'default' => true],
                'sections' => ['type' => 'array', 'default' => self::default_home_stack_sections()],
                'rubricsTitle' => ['type' => 'string', 'default' => 'Рубрики'],
                'rubricsOpen' => ['type' => 'boolean', 'default' => true],
                'categories' => ['type' => 'array', 'default' => self::default_home_stack_categories()],
            ],
            'render_callback' => [self::class, 'render_home_stack'],
        ], self::SCRIPT_HOME));

        register_block_type('slavyanbank-stage1/contact-channels', self::shared_block_args([
            'attributes' => [
                'items' => ['type' => 'array', 'default' => self::default_contact_channels_items()],
            ],
            'render_callback' => [self::class, 'render_contact_channels'],
        ], self::SCRIPT_CONTACTS));

        register_block_type('slavyanbank-stage1/contact-route-actions', self::shared_block_args([
            'attributes' => [
                'kicker' => ['type' => 'string', 'default' => 'Как нас найти'],
                'title' => ['type' => 'string', 'default' => 'г. Великий Новгород, ул. Черемнова-Конюхова, дом 12'],
                'actions' => ['type' => 'array', 'default' => self::default_contact_route_actions()],
                'primaryButtonText' => ['type' => 'string', 'default' => 'Маршрут в Яндекс Картах →'],
                'primaryButtonUrl' => ['type' => 'string', 'default' => 'https://yandex.ru/maps/?text=г. Великий Новгород, ул. Черемнова-Конюхова, дом 12'],
                'secondaryButtonText' => ['type' => 'string', 'default' => 'Маршрут в Google Maps →'],
                'secondaryButtonUrl' => ['type' => 'string', 'default' => 'https://www.google.com/maps/search/?api=1&query=г. Великий Новгород, ул. Черемнова-Конюхова, дом 12'],
            ],
            'render_callback' => [self::class, 'render_contact_route_actions'],
        ], self::SCRIPT_CONTACTS));

        register_block_type('slavyanbank-stage1/section-shell', self::shared_block_args([
            'attributes' => [
                'variant' => ['type' => 'string', 'default' => 'default'],
                'anchor' => ['type' => 'string', 'default' => ''],
            ],
        ], self::SCRIPT_LAYOUT));

        register_block_type('slavyanbank-stage1/bento-layout', self::shared_block_args([], self::SCRIPT_LAYOUT));

        register_block_type('slavyanbank-stage1/bento-card-shell', self::shared_block_args([
            'attributes' => [
                'padding' => ['type' => 'string', 'default' => 'var(--s-4)'],
                'positionRelative' => ['type' => 'boolean', 'default' => true],
            ],
        ], self::SCRIPT_LAYOUT));

        register_block_type('slavyanbank-stage1/stack-shell', self::shared_block_args([], self::SCRIPT_LAYOUT));

        register_block_type('slavyanbank-stage1/prose-shell', self::shared_block_args([], self::SCRIPT_LAYOUT));
    }

    private static function default_document_shelf_items(): array {
        return [
            [
                'title'  => 'Годовая бухгалтерская (финансовая) отчетность за 2024 год.',
                'footer' => '(Опубликовано 11.04.2025г. Утверждена на годовом ОСА 10.04.2025г.)',
                'url'    => 'https://slavbank.ru/wp-content/uploads/azo_-2024_nmm_slavyanbank.pdf',
                'kind'   => 'PDF',
                'newTab' => true,
            ],
            [
                'title'  => 'Годовая бухгалтерская (финансовая) отчетность за 2023 год.',
                'footer' => '(Опубликовано 12.03.2024г. Утверждена на годовом ОСА 02.04.2024г.)',
                'url'    => 'https://slavbank.ru/wp-content/uploads/otchet_2023_publ.pdf',
                'kind'   => 'PDF',
                'newTab' => true,
            ],
        ];
    }

    private static function default_document_rows_items(): array {
        return [
            [
                'date'  => '29.09.2021',
                'title' => 'Список аффилированных лиц',
                'url'   => 'https://slavbank.ru/wp-content/uploads/afl29092021.xls',
                'kind'  => 'XLS',
                'newTab' => true,
            ],
            [
                'date'  => '30.06.2021',
                'title' => 'Список аффилированных лиц',
                'url'   => 'https://slavbank.ru/wp-content/uploads/afl30062021.xls',
                'kind'  => 'XLS',
                'newTab' => true,
            ],
        ];
    }

    private static function default_tariff_items(): array {
        return [
            [
                'date'  => 'с 01.01.2026г',
                'title' => 'Тарифы банка в валюте РФ.',
                'url'   => 'https://slavbank.ru/wp-content/uploads/standard-osobiy-s-01012026.pdf',
                'newTab' => true,
            ],
            [
                'date'  => 'с 01.12.2025г',
                'title' => 'Тарифы банка в иностранной валюте.',
                'url'   => 'https://slavbank.ru/wp-content/uploads/tarify-v-in-valyute-s-01122025.pdf',
                'newTab' => true,
            ],
        ];
    }

    private static function default_document_tabs_items(): array {
        return [
            [
                'key' => 'aff',
                'label' => 'Аффилированные лица',
                'intro' => 'Списки аффилированных лиц в формате XLS. В подборке собраны опубликованные документы, размещенные в корпоративном разделе банка.',
                'panelType' => 'rows',
                'rows' => self::default_document_rows_items(),
                'heroTitle' => '',
                'heroSubtitle' => '',
                'heroUrl' => '',
                'heroNewTab' => true,
            ],
            [
                'key' => 'control',
                'label' => 'Список лиц, под контролем или значительным влиянием',
                'intro' => 'Опубликовано: 20.07.2018 · Актуализировано: 25.03.2020. Документ доступен в формате PDF.',
                'panelType' => 'hero',
                'rows' => [],
                'heroTitle' => 'Список лиц, под контролем или значительным влиянием которых находится банк',
                'heroSubtitle' => 'Скачать PDF',
                'heroUrl' => 'https://slavbank.ru/wp-content/uploads/2021/03/spisok250320.pdf',
                'heroNewTab' => true,
            ],
            [
                'key' => 'msg',
                'label' => 'Сообщения',
                'intro' => 'Сообщения об утверждении годовой бухгалтерской (финансовой) отчетности.',
                'panelType' => 'rows',
                'rows' => [
                    [
                        'date' => '2019',
                        'title' => 'Сообщение об утверждении годовой бухгалтерской (финансовой) отчетности за 2019 год · 17 апреля 2020',
                        'url' => 'https://slavbank.ru/wp-content/uploads/2021/03/message_rep2019.pdf',
                        'kind' => 'PDF',
                        'newTab' => true,
                    ],
                    [
                        'date' => '2020',
                        'title' => 'Сообщение об утверждении годовой бухгалтерской (финансовой) отчетности за 2020 год · 23 апреля 2021',
                        'url' => 'https://slavbank.ru/wp-content/uploads/message_rep2020.pdf',
                        'kind' => 'PDF',
                        'newTab' => true,
                    ],
                ],
                'heroTitle' => '',
                'heroSubtitle' => '',
                'heroUrl' => '',
            ],
        ];
    }

    private static function default_reporting_sections(): array {
        return [
            [
                'summary' => 'Промежуточная бухгалтерская (финансовая) отчетность за 2025 год',
                'open' => true,
                'entries' => [
                    [
                        'title' => 'Промежуточная бухгалтерская (финансовая) отчетность за I квартал 2025 г.',
                        'note' => '(опубликовано 16.05.2025г.)',
                        'url' => 'https://slavbank.ru/wp-content/uploads/otchet-publ-i-2025.pdf',
                        'newTab' => true,
                    ],
                    [
                        'title' => 'Промежуточная бухгалтерская (финансовая) отчетность за I полугодие 2025 г.',
                        'note' => '(опубликовано 07.08.2025г.)',
                        'url' => 'https://slavbank.ru/wp-content/uploads/otchet-publ-ii-2025.pdf',
                        'newTab' => true,
                    ],
                    [
                        'title' => 'Промежуточная бухгалтерская (финансовая) отчетность за 9 месяцев 2025 г.',
                        'note' => '(опубликовано 12.11.2025г.)',
                        'url' => 'https://slavbank.ru/wp-content/uploads/otchet-publ-9-2025.pdf',
                        'newTab' => true,
                    ],
                ],
            ],
            [
                'summary' => 'Промежуточная бухгалтерская (финансовая) отчетность за 2024 год',
                'open' => false,
                'entries' => [
                    [
                        'title' => 'Промежуточная бухгалтерская (финансовая) отчетность за I квартал 2024 г.',
                        'note' => '(опубликовано 16.05.2024г.)',
                        'url' => 'https://slavbank.ru/wp-content/uploads/otchet_publ-1-24-1.pdf',
                        'newTab' => true,
                    ],
                    [
                        'title' => 'Промежуточная бухгалтерская (финансовая) отчетность за I полугодие 2024 г.',
                        'note' => '(опубликовано 09.08.2024г.)',
                        'url' => 'https://slavbank.ru/wp-content/uploads/na-sajt-otchet-2-2024-publ.pdf',
                        'newTab' => true,
                    ],
                    [
                        'title' => 'Промежуточная бухгалтерская (финансовая) отчетность за 9 месяцев 2024 г.',
                        'note' => '(опубликовано 08.11.2024г.)',
                        'url' => 'https://slavbank.ru/wp-content/uploads/otchet-publ-9-2024.pdf',
                        'newTab' => true,
                    ],
                ],
            ],
        ];
    }

    private static function default_requisites_items(): array {
        return [
            [
                'label' => 'Сокращенное наименование',
                'value' => 'АО НКБ «СЛАВЯНБАНК»',
                'copy'  => 'АО НКБ «СЛАВЯНБАНК»',
                'url'   => '',
                'external' => false,
            ],
            [
                'label' => 'Адрес электронной почты',
                'value' => 'nkb@slavbank.ru',
                'copy'  => 'nkb@slavbank.ru',
                'url'   => 'mailto:nkb@slavbank.ru',
                'external' => false,
            ],
        ];
    }

    private static function default_support_topics_items(): array {
        return [
            [
                'title' => 'Часто задаваемые вопросы',
                'text'  => 'Открыть раздел →',
                'url'   => '/faq/',
            ],
            [
                'title' => 'Перегенерация ЭЦП',
                'text'  => 'Открыть раздел →',
                'url'   => '/ecp-regeneration/',
            ],
            [
                'title' => 'Рекомендации по безопасности',
                'text'  => 'Открыть раздел →',
                'url'   => '/security/',
            ],
        ];
    }

    private static function default_service_links_items(): array {
        return [
            [
                'title' => 'Безопасность',
                'url'   => '/security/',
                'ghost' => false,
            ],
            [
                'title' => 'Клиент-Банк',
                'url'   => '/client-bank-online/',
                'ghost' => false,
            ],
            [
                'title' => '123-ФЗ',
                'url'   => '/appeal-123-fz/',
                'ghost' => true,
            ],
        ];
    }


    private static function default_home_stack_rates(): array {
        return [
            ['code' => 'USD', 'buy' => '89.40', 'sell' => '92.30', 'visible' => true],
            ['code' => 'EUR', 'buy' => '96.80', 'sell' => '99.90', 'visible' => true],
        ];
    }

    private static function default_home_stack_publications(): array {
        return [
            ['date' => '05.04.2026', 'title' => 'Изменения в тарифах банка', 'url' => '/novosti/', 'external' => false],
            ['date' => '01.04.2026', 'title' => 'Обновление раздела отчетности', 'url' => '/otchetnost/', 'external' => false],
        ];
    }

    private static function default_home_stack_sections(): array {
        return [
            ['label' => 'ИНФОРМАЦИЯ БАНКА', 'url' => '/informaciya-banka/', 'external' => false],
            ['label' => 'НОВОСТИ', 'url' => '/novosti/', 'external' => false],
            ['label' => 'ТАРИФЫ БАНКА', 'url' => '/tarify-banka/', 'external' => false],
            ['label' => 'ЮРИДИЧЕСКИМ ЛИЦАМ', 'url' => '/yuridicheskim-licam/', 'external' => false],
            ['label' => 'ПОДДЕРЖКА', 'url' => '/podderzhka/', 'external' => false],
            ['label' => 'КОНТАКТЫ', 'url' => '/kontakty/', 'external' => false],
        ];
    }

    private static function default_home_stack_categories(): array {
        return [
            ['label' => 'Новости', 'url' => '/novosti/', 'external' => false],
            ['label' => 'Полезная информация', 'url' => '/novosti/', 'external' => false],
            ['label' => 'АРХИВ', 'url' => 'https://slavbank.ru/category/arhiv', 'external' => true],
        ];
    }

    private static function default_contact_channels_items(): array {
        return [
            [
                'label' => 'Телефон',
                'value' => '8162665247',
                'valueUrl' => 'tel:78162665247',
                'description' => 'Единый номер банка',
                'copyValue' => '8162665247',
                'actions' => [
                    ['text' => 'Позвонить', 'url' => 'tel:78162665247', 'variant' => 'outline', 'newTab' => false],
                ],
            ],
            [
                'label' => 'Электронная почта',
                'value' => 'nkb@slavbank.ru',
                'valueUrl' => 'mailto:nkb@slavbank.ru',
                'description' => 'Для общих вопросов и документов',
                'copyValue' => 'nkb@slavbank.ru',
                'actions' => [
                    ['text' => 'Написать', 'url' => 'mailto:nkb@slavbank.ru', 'variant' => 'outline', 'newTab' => false],
                ],
            ],
            [
                'label' => 'Адрес',
                'value' => 'г. Великий Новгород, ул. Черемнова-Конюхова, дом 12',
                'valueUrl' => '',
                'description' => 'Головной офис',
                'copyValue' => 'г. Великий Новгород, ул. Черемнова-Конюхова, дом 12',
                'actions' => [
                    ['text' => 'Открыть в Яндекс Картах', 'url' => 'https://yandex.ru/maps/?text=г. Великий Новгород, ул. Черемнова-Конюхова, дом 12', 'variant' => 'outline', 'newTab' => true],
                    ['text' => 'Открыть в Google Maps', 'url' => 'https://www.google.com/maps/search/?api=1&query=г. Великий Новгород, ул. Черемнова-Конюхова, дом 12', 'variant' => 'outline', 'newTab' => true],
                ],
            ],
        ];
    }


    private static function default_hero_actions(): array {
        return [
            ['text' => 'Содержание', 'url' => '#content', 'variant' => 'primary', 'newTab' => false],
            ['text' => 'На главную', 'url' => '/', 'variant' => 'outline', 'newTab' => false],
        ];
    }

    private static function default_hero_meta_items(): array {
        return [
            ['text' => 'Реквизиты', 'url' => '/rekvizity-banka/', 'className' => 'mono badge', 'newTab' => false],
            ['text' => 'Информация банка', 'url' => '/informaciya-banka/', 'className' => 'mono badge', 'newTab' => false],
        ];
    }

    private static function default_contact_route_actions(): array {
        return [
            ['text' => 'Маршрут в Яндекс Картах →', 'url' => 'https://yandex.ru/maps/?text=г. Великий Новгород, ул. Черемнова-Конюхова, дом 12', 'variant' => 'primary', 'newTab' => true],
            ['text' => 'Маршрут в Google Maps →', 'url' => 'https://www.google.com/maps/search/?api=1&query=г. Великий Новгород, ул. Черемнова-Конюхова, дом 12', 'variant' => 'outline', 'newTab' => true],
        ];
    }

    private static function string_attr(array $attributes, string $key, string $default = ''): string {
        return isset($attributes[$key]) ? (string) $attributes[$key] : $default;
    }

    private static function array_attr(array $attributes, string $key): array {
        $value = $attributes[$key] ?? [];

        return is_array($value) ? $value : [];
    }

    private static function rel_attr(array $item): string {
        $rel = isset($item['rel']) && is_string($item['rel']) && $item['rel'] !== '' ? $item['rel'] : 'noopener';

        return ' rel="' . esc_attr($rel) . '"';
    }

    private static function target_attr(array $item): string {
        $target = isset($item['target']) && is_string($item['target']) && $item['target'] !== '' ? $item['target'] : '_blank';

        return ' target="' . esc_attr($target) . '"';
    }

    private static function class_list_attr(string $classes): string {
        $classes = trim($classes);
        if ($classes == '') {
            return '';
        }

        $tokens = preg_split('/\s+/', $classes) ?: [];
        $tokens = array_values(array_filter(array_map('sanitize_html_class', $tokens)));
        if (empty($tokens)) {
            return '';
        }

        return implode(' ', $tokens);
    }

    private static function new_tab_attrs(array $item): string {
        return !empty($item['newTab']) ? ' target="_blank" rel="noopener"' : '';
    }

    private static function link_attrs(array $item, bool $default_new_tab = false): string {
        if (array_key_exists('newTab', $item)) {
            return !empty($item['newTab']) ? ' target="_blank" rel="noopener"' : '';
        }

        if (array_key_exists('external', $item)) {
            return !empty($item['external']) ? ' target="_blank" rel="noopener"' : '';
        }

        return $default_new_tab ? ' target="_blank" rel="noopener"' : '';
    }

    private static function hero_actions_from_attributes(array $attributes): array {
        $items = self::array_attr($attributes, 'actions');
        if (!empty($items)) {
            return $items;
        }

        $legacy = [];
        $primary_text = self::string_attr($attributes, 'primaryButtonText', '');
        $primary_url = self::string_attr($attributes, 'primaryButtonUrl', '');
        $secondary_text = self::string_attr($attributes, 'secondaryButtonText', '');
        $secondary_url = self::string_attr($attributes, 'secondaryButtonUrl', '');

        if ($primary_text !== '' || $primary_url !== '') {
            $legacy[] = ['text' => $primary_text, 'url' => $primary_url, 'variant' => 'primary', 'newTab' => false];
        }
        if ($secondary_text !== '' || $secondary_url !== '') {
            $legacy[] = ['text' => $secondary_text, 'url' => $secondary_url, 'variant' => 'outline', 'newTab' => false];
        }

        return $legacy;
    }

    private static function hero_meta_items_from_attributes(array $attributes): array {
        $items = self::array_attr($attributes, 'metaItems');
        if (!empty($items)) {
            return $items;
        }

        $legacy = [];
        $badge1_text = self::string_attr($attributes, 'badge1Text', '');
        $badge1_url = self::string_attr($attributes, 'badge1Url', '');
        $badge2_text = self::string_attr($attributes, 'badge2Text', '');
        $badge2_url = self::string_attr($attributes, 'badge2Url', '');

        if ($badge1_text !== '' || $badge1_url !== '') {
            $legacy[] = ['text' => $badge1_text, 'url' => $badge1_url, 'className' => 'mono badge', 'newTab' => false];
        }
        if ($badge2_text !== '' || $badge2_url !== '') {
            $legacy[] = ['text' => $badge2_text, 'url' => $badge2_url, 'className' => 'mono badge', 'newTab' => false];
        }

        return $legacy;
    }


    private static function contact_actions_from_item(array $item): array {
        $actions = isset($item['actions']) && is_array($item['actions']) ? $item['actions'] : [];
        $actions = array_values(array_filter($actions, static function ($action): bool {
            return is_array($action) && ((string) ($action['text'] ?? '') !== '' || (string) ($action['url'] ?? '') !== '');
        }));
        if (!empty($actions)) {
            return $actions;
        }

        $legacy = [];
        $action1_text = isset($item['action1Text']) ? (string) $item['action1Text'] : '';
        $action1_url = isset($item['action1Url']) ? (string) $item['action1Url'] : '';
        $action2_text = isset($item['action2Text']) ? (string) $item['action2Text'] : '';
        $action2_url = isset($item['action2Url']) ? (string) $item['action2Url'] : '';

        if ($action1_text !== '' || $action1_url !== '') {
            $legacy[] = ['text' => $action1_text, 'url' => $action1_url, 'variant' => 'outline', 'newTab' => false];
        }
        if ($action2_text !== '' || $action2_url !== '') {
            $legacy[] = ['text' => $action2_text, 'url' => $action2_url, 'variant' => 'outline', 'newTab' => true];
        }

        return $legacy;
    }

    private static function contact_route_actions_from_attributes(array $attributes): array {
        $items = self::array_attr($attributes, 'actions');
        if (!empty($items)) {
            return $items;
        }

        $legacy = [];
        $primary_text = self::string_attr($attributes, 'primaryButtonText', '');
        $primary_url = self::string_attr($attributes, 'primaryButtonUrl', '');
        $secondary_text = self::string_attr($attributes, 'secondaryButtonText', '');
        $secondary_url = self::string_attr($attributes, 'secondaryButtonUrl', '');

        if ($primary_text !== '' || $primary_url !== '') {
            $legacy[] = ['text' => $primary_text, 'url' => $primary_url, 'variant' => 'primary', 'newTab' => true];
        }
        if ($secondary_text !== '' || $secondary_url !== '') {
            $legacy[] = ['text' => $secondary_text, 'url' => $secondary_url, 'variant' => 'outline', 'newTab' => true];
        }

        return $legacy;
    }

    public static function render_alert(array $attributes): string {
        $title = self::string_attr($attributes, 'title', '');
        $text = self::string_attr($attributes, 'text', '');

        ob_start();
        ?>
        <div class="alert">
            <div class="alert-dot" aria-hidden="true"></div>
            <div>
                <?php if ($title !== '') : ?>
                    <div style="font-weight:600;"><?php echo esc_html($title); ?></div>
                <?php endif; ?>
                <?php if ($text !== '') : ?>
                    <div class="muted" style="margin-top:4px;"><?php echo esc_html($text); ?></div>
                <?php endif; ?>
            </div>
        </div>
        <?php
        return trim((string) ob_get_clean());
    }

    public static function render_hero_shell(array $attributes): string {
        $kicker = self::string_attr($attributes, 'kicker', '');
        $title = self::string_attr($attributes, 'title', '');
        $text = self::string_attr($attributes, 'text', '');
        $actions = self::hero_actions_from_attributes($attributes);
        $meta_items = self::hero_meta_items_from_attributes($attributes);

        ob_start();
        ?>
        <section class="block">
            <div class="container">
                <div class="hero-wrap" style="padding: var(--s-5)">
                    <div class="row" style="align-items: flex-start; gap: var(--s-4); flex-wrap: wrap">
                        <div style="min-width: 280px; flex: 1 1 520px">
                            <?php if ($kicker !== '') : ?>
                                <div class="kicker"><?php echo esc_html($kicker); ?></div>
                            <?php endif; ?>
                            <?php if ($title !== '') : ?>
                                <h1 style="margin: 8px 0 10px"><?php echo esc_html($title); ?></h1>
                            <?php endif; ?>
                            <?php if ($text !== '') : ?>
                                <p style="max-width: 78ch"><?php echo esc_html($text); ?></p>
                            <?php endif; ?>

                            <?php if (!empty($actions)) : ?>
                                <div class="row" style="margin-top: var(--s-4); flex-wrap: wrap">
                                    <?php foreach ($actions as $item) :
                                        if (!is_array($item)) { continue; }
                                        $item_text = isset($item['text']) ? (string) $item['text'] : '';
                                        $item_url = isset($item['url']) ? (string) $item['url'] : '';
                                        $variant = isset($item['variant']) ? (string) $item['variant'] : '';
                                        $btn_class = trim('btn ' . sanitize_html_class($variant));
                                        if ($item_text === '' || $item_url === '') { continue; }
                                        ?>
                                        <a class="<?php echo esc_attr($btn_class); ?>" href="<?php echo esc_url($item_url); ?>"<?php echo self::new_tab_attrs($item); ?>><?php echo esc_html($item_text); ?></a>
                                    <?php endforeach; ?>
                                </div>
                            <?php endif; ?>
                        </div>

                        <?php if (!empty($meta_items)) : ?>
                            <div class="pill" style="align-self: flex-start">
                                <?php foreach ($meta_items as $index => $item) :
                                    if (!is_array($item)) { continue; }
                                    $item_text = isset($item['text']) ? (string) $item['text'] : '';
                                    $item_url = isset($item['url']) ? (string) $item['url'] : '';
                                    $class_name = self::class_list_attr(isset($item['className']) ? (string) $item['className'] : '');
                                    if ($item_text === '') { continue; }
                                    if ($index > 0) : ?><span class="muted">·</span><?php endif; ?>
                                    <?php if ($item_url !== '') : ?>
                                        <a href="<?php echo esc_url($item_url); ?>"<?php echo $class_name !== '' ? ' class="' . esc_attr($class_name) . '"' : ''; ?><?php echo self::new_tab_attrs($item); ?>><?php echo esc_html($item_text); ?></a>
                                    <?php else : ?>
                                        <span<?php echo $class_name !== '' ? ' class="' . esc_attr($class_name) . '"' : ''; ?>><?php echo esc_html($item_text); ?></span>
                                    <?php endif; ?>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </section>
        <?php
        return trim((string) ob_get_clean());
    }

    public static function render_document_shelf(array $attributes): string {
        $items = self::array_attr($attributes, 'items');

        ob_start();
        ?>
        <div class="doc-shelf">
            <?php foreach ($items as $item) :
                if (!is_array($item)) {
                    continue;
                }
                $title = isset($item['title']) ? (string) $item['title'] : '';
                $footer = isset($item['footer']) ? (string) $item['footer'] : '';
                $url = isset($item['url']) ? (string) $item['url'] : '';
                $kind = isset($item['kind']) ? (string) $item['kind'] : 'PDF';
                if ($title === '' || $url === '') {
                    continue;
                }
                ?>
                <a class="doc-card" href="<?php echo esc_url($url); ?>"<?php echo self::link_attrs($item, true); ?>>
                    <span class="doc-ext"><?php echo esc_html($kind); ?></span>
                    <div class="doc-body">
                        <div class="doc-title"><?php echo esc_html($title); ?></div>
                        <?php if ($footer !== '') : ?>
                            <div style="font-size: 10px" class="muted"><?php echo esc_html($footer); ?></div>
                        <?php endif; ?>
                    </div>
                    <span class="doc-arrow">→</span>
                </a>
            <?php endforeach; ?>
        </div>
        <?php
        return trim((string) ob_get_clean());
    }

    private static function render_document_rows_markup(array $items, string $style = 'margin-top: 12px;'): string {
        ob_start();
        ?>
        <div class="doc-list"<?php echo $style !== '' ? ' style="' . esc_attr($style) . '"' : ''; ?>>
            <?php foreach ($items as $item) :
                if (!is_array($item)) {
                    continue;
                }
                $date = isset($item['date']) ? (string) $item['date'] : '';
                $title = isset($item['title']) ? (string) $item['title'] : '';
                $url = isset($item['url']) ? (string) $item['url'] : '';
                $kind = isset($item['kind']) ? (string) $item['kind'] : 'PDF';
                if ($title === '' || $url === '') {
                    continue;
                }
                ?>
                <a class="doc-row" href="<?php echo esc_url($url); ?>"<?php echo self::link_attrs($item, true); ?>>
                    <span class="doc-date"><?php echo esc_html($date); ?></span>
                    <span class="doc-title"><?php echo esc_html($title); ?></span>
                    <span class="doc-ext"><?php echo esc_html($kind); ?></span>
                    <span class="doc-arrow" aria-hidden="true">→</span>
                </a>
            <?php endforeach; ?>
        </div>
        <?php
        return trim((string) ob_get_clean());
    }

    public static function render_document_rows(array $attributes): string {
        $items = self::array_attr($attributes, 'items');

        return self::render_document_rows_markup($items, 'margin-top: 12px;');
    }

    private static function render_document_hero_markup(array $item, string $style = ''): string {
        $title = isset($item['title']) ? (string) $item['title'] : '';
        $subtitle = isset($item['subtitle']) ? (string) $item['subtitle'] : '';
        $url = isset($item['url']) ? (string) $item['url'] : '#';

        ob_start();
        ?>
        <a class="doc-hero" href="<?php echo esc_url($url); ?>"<?php echo self::link_attrs($item, true); ?><?php echo $style !== '' ? ' style="' . esc_attr($style) . '"' : ''; ?>>
            <span class="ico" aria-hidden="true">
                <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
                    <path d="M7 3h7l3 3v15a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2Z" stroke="currentColor" stroke-width="2" opacity=".8" />
                    <path d="M14 3v4a2 2 0 0 0 2 2h4" stroke="currentColor" stroke-width="2" opacity=".5" />
                </svg>
            </span>
            <span>
                <strong><?php echo esc_html($title); ?></strong>
                <small class="muted"><?php echo esc_html($subtitle); ?></small>
            </span>
            <span class="arrow" aria-hidden="true">→</span>
        </a>
        <?php
        return trim((string) ob_get_clean());
    }

    public static function render_document_hero(array $attributes): string {
        return self::render_document_hero_markup([
            'title' => self::string_attr($attributes, 'title', ''),
            'subtitle' => self::string_attr($attributes, 'subtitle', ''),
            'url' => self::string_attr($attributes, 'url', '#'),
            'newTab' => array_key_exists('newTab', $attributes) ? !empty($attributes['newTab']) : true,
        ]);
    }

    public static function render_document_tabs(array $attributes): string {
        $tabs = self::array_attr($attributes, 'tabs');
        $aria_label = self::string_attr($attributes, 'ariaLabel', 'Документы банка');
        $active_tab = self::string_attr($attributes, 'activeTab', '');

        if ($active_tab === '' && !empty($tabs) && is_array($tabs[0])) {
            $active_tab = isset($tabs[0]['key']) ? (string) $tabs[0]['key'] : '';
        }

        ob_start();
        ?>
        <div class="dashv2">
            <div class="bento-card bento-hero" style="padding: var(--s-4);">
                <div class="section-flow">
                    <div class="dash-tabs" role="tablist" aria-label="<?php echo esc_attr($aria_label); ?>">
                        <?php foreach ($tabs as $tab) :
                            if (!is_array($tab)) {
                                continue;
                            }
                            $key = isset($tab['key']) ? (string) $tab['key'] : '';
                            $label = isset($tab['label']) ? (string) $tab['label'] : '';
                            if ($key === '' || $label === '') {
                                continue;
                            }
                            $is_active = ($key === $active_tab);
                            ?>
                            <button class="seg" role="tab" type="button" data-doc-tab="<?php echo esc_attr($key); ?>" aria-selected="<?php echo $is_active ? 'true' : 'false'; ?>">
                                <?php echo esc_html($label); ?>
                            </button>
                        <?php endforeach; ?>
                    </div>

                    <div class="dash-panels">
                        <?php foreach ($tabs as $tab) :
                            if (!is_array($tab)) {
                                continue;
                            }
                            $key = isset($tab['key']) ? (string) $tab['key'] : '';
                            if ($key === '') {
                                continue;
                            }
                            $intro = isset($tab['intro']) ? (string) $tab['intro'] : '';
                            $panel_type = isset($tab['panelType']) ? (string) $tab['panelType'] : 'rows';
                            $is_active = ($key === $active_tab);
                            ?>
                            <div class="dash-panel<?php echo $is_active ? ' is-active' : ''; ?>" data-doc-panel="<?php echo esc_attr($key); ?>"<?php echo $is_active ? '' : ' hidden'; ?>>
                                <?php if ($intro !== '') : ?>
                                    <div class="muted" style="line-height: 1.6;">
                                        <?php echo esc_html($intro); ?>
                                    </div>
                                <?php endif; ?>

                                <?php if ($panel_type === 'hero') : ?>
                                    <?php
                                    echo self::render_document_hero_markup([
                                        'title' => isset($tab['heroTitle']) ? (string) $tab['heroTitle'] : '',
                                        'subtitle' => isset($tab['heroSubtitle']) ? (string) $tab['heroSubtitle'] : '',
                                        'url' => isset($tab['heroUrl']) ? (string) $tab['heroUrl'] : '#',
                                        'newTab' => array_key_exists('heroNewTab', $tab) ? !empty($tab['heroNewTab']) : true,
                                    ], 'margin-top: 12px;');
                                    ?>
                                <?php else : ?>
                                    <?php echo self::render_document_rows_markup(isset($tab['rows']) && is_array($tab['rows']) ? $tab['rows'] : [], 'margin-top: 12px;'); ?>
                                <?php endif; ?>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        </div>
        <?php
        return trim((string) ob_get_clean());
    }

    public static function render_tariff_card_list(array $attributes): string {
        $items = self::array_attr($attributes, 'items');

        ob_start();
        ?>
        <ul>
            <?php foreach ($items as $item) :
                if (!is_array($item)) {
                    continue;
                }
                $date = isset($item['date']) ? (string) $item['date'] : '';
                $title = isset($item['title']) ? (string) $item['title'] : '';
                $url = isset($item['url']) ? (string) $item['url'] : '';
                if ($title === '' || $url === '') {
                    continue;
                }
                ?>
                <li>
                    <a class="doc-card" href="<?php echo esc_url($url); ?>"<?php echo self::link_attrs($item, true); ?>>
                        <span class="doc-title"><strong><?php echo esc_html($title); ?></strong></span>
                        <?php if ($date !== '') : ?>
                            <span class="doc-arrow doc-ext" style="text-align: center; min-width: 132px;"><?php echo esc_html($date); ?></span>
                        <?php endif; ?>
                    </a>
                </li>
            <?php endforeach; ?>
        </ul>
        <?php
        return trim((string) ob_get_clean());
    }

    public static function render_requisites_table(array $attributes): string {
        $items = self::array_attr($attributes, 'items');

        ob_start();
        ?>
        <div class="table-wrap">
            <table class="req-table">
                <thead>
                    <tr>
                        <th>Параметр</th>
                        <th>Значение</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($items as $item) :
                        if (!is_array($item)) {
                            continue;
                        }
                        $label = isset($item['label']) ? (string) $item['label'] : '';
                        $value = isset($item['value']) ? (string) $item['value'] : '';
                        $copy = isset($item['copy']) && is_string($item['copy']) && $item['copy'] !== '' ? (string) $item['copy'] : $value;
                        $url = isset($item['url']) ? (string) $item['url'] : '';
                        $external = !empty($item['external']);
                        if ($label === '' || $value === '') {
                            continue;
                        }
                        ?>
                        <tr>
                            <td><?php echo nl2br(esc_html($label)); ?></td>
                            <td>
                                <?php if ($url !== '') : ?>
                                    <a href="<?php echo esc_url($url); ?>"<?php echo $external ? ' target="_blank" rel="noopener"' : ''; ?>><?php echo nl2br(esc_html($value)); ?></a>
                                <?php else : ?>
                                    <?php echo nl2br(esc_html($value)); ?>
                                <?php endif; ?>
                            </td>
                            <td>
                                <button class="copy mini" type="button" data-copy="<?php echo esc_attr($copy); ?>">Копировать</button>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php
        return trim((string) ob_get_clean());
    }

    public static function render_support_topics_grid(array $attributes): string {
        $items = self::array_attr($attributes, 'items');

        ob_start();
        ?>
        <div class="tiles">
            <?php foreach ($items as $item) :
                if (!is_array($item)) {
                    continue;
                }
                $title = isset($item['title']) ? (string) $item['title'] : '';
                $text = isset($item['text']) ? (string) $item['text'] : '';
                $url = isset($item['url']) ? (string) $item['url'] : '';
                if ($title === '' || $url === '') {
                    continue;
                }
                ?>
                <a class="tile" href="<?php echo esc_url($url); ?>"<?php echo self::link_attrs($item, false); ?>>
                    <div class="tile-title"><?php echo esc_html($title); ?></div>
                    <?php if ($text !== '') : ?>
                        <div class="muted" style="margin-top:6px;"><?php echo esc_html($text); ?></div>
                    <?php endif; ?>
                </a>
            <?php endforeach; ?>
        </div>
        <?php
        return trim((string) ob_get_clean());
    }

    public static function render_service_links(array $attributes): string {
        $items = self::array_attr($attributes, 'items');

        ob_start();
        ?>
        <div class="svc-grid">
            <?php foreach ($items as $item) :
                if (!is_array($item)) {
                    continue;
                }
                $title = isset($item['title']) ? (string) $item['title'] : '';
                $url = isset($item['url']) ? (string) $item['url'] : '';
                $ghost = !empty($item['ghost']);
                if ($title === '' || $url === '') {
                    continue;
                }
                ?>
                <a class="svc-chip<?php echo $ghost ? ' ghost' : ''; ?>" href="<?php echo esc_url($url); ?>"<?php echo self::link_attrs($item, false); ?>>
                    <span><?php echo esc_html($title); ?></span>
                    <span aria-hidden="true">→</span>
                </a>
            <?php endforeach; ?>
        </div>
        <?php
        return trim((string) ob_get_clean());
    }

    public static function render_reporting_accordion(array $attributes): string {
        $title = self::string_attr($attributes, 'title', '');
        $subtitle = self::string_attr($attributes, 'subtitle', '');
        $sections = self::array_attr($attributes, 'sections');

        ob_start();
        ?>
        <div class="dashv2">
            <div class="bento-card" style="padding: var(--s-4); position: relative">
                <div class="prose">
                    <div class="entry-content">
                        <?php if ($title !== '') : ?>
                            <h3 class="kicker"><strong><?php echo esc_html($title); ?></strong></h3>
                        <?php endif; ?>
                        <?php if ($subtitle !== '') : ?>
                            <h4 class="kicker"><strong><?php echo esc_html($subtitle); ?></strong></h4>
                        <?php endif; ?>

                        <?php foreach ($sections as $section) :
                            if (!is_array($section)) {
                                continue;
                            }
                            $summary = isset($section['summary']) ? (string) $section['summary'] : '';
                            $entries = isset($section['entries']) && is_array($section['entries']) ? $section['entries'] : [];
                            $is_open = !empty($section['open']);
                            if ($summary === '') {
                                continue;
                            }
                            ?>
                            <details class="wp-block-details has-gray-color has-text-color has-link-color is-layout-flow wp-block-details-is-layout-flow"<?php echo $is_open ? ' open' : ''; ?>>
                                <summary><strong><?php echo esc_html($summary); ?></strong></summary>
                                <figure class="wp-block-table is-style-stripes">
                                    <table class="has-fixed-layout">
                                        <tbody>
                                            <?php foreach ($entries as $entry) :
                                                if (!is_array($entry)) {
                                                    continue;
                                                }
                                                $entry_title = isset($entry['title']) ? (string) $entry['title'] : '';
                                                $entry_note = isset($entry['note']) ? (string) $entry['note'] : '';
                                                $entry_url = isset($entry['url']) ? (string) $entry['url'] : '';
                                                if ($entry_title === '' || $entry_url === '') {
                                                    continue;
                                                }
                                                ?>
                                                <tr>
                                                    <td class="has-text-align-center" data-align="center">
                                                        <a href="<?php echo esc_url($entry_url); ?>"<?php echo self::link_attrs($entry, true); ?>>
                                                            <strong><?php echo esc_html($entry_title); ?></strong>
                                                            <?php if ($entry_note !== '') : ?>
                                                                <br /><sub><?php echo esc_html($entry_note); ?></sub>
                                                            <?php endif; ?>
                                                        </a>
                                                    </td>
                                                </tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                </figure>
                            </details>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        </div>
        <?php
        return trim((string) ob_get_clean());
    }

    public static function render_home_stack(array $attributes): string {
        $currency_title = self::string_attr($attributes, 'currencyTitle', '');
        $date_line = self::string_attr($attributes, 'dateLine', '');
        $legend_title = self::string_attr($attributes, 'legendTitle', '');
        $buy_label = self::string_attr($attributes, 'buyLabel', '');
        $sell_label = self::string_attr($attributes, 'sellLabel', '');
        $footer_text = self::string_attr($attributes, 'footerText', '');
        $rates = self::array_attr($attributes, 'rates');
        $publications_title = self::string_attr($attributes, 'publicationsTitle', '');
        $publications_kicker = self::string_attr($attributes, 'publicationsKicker', '');
        $publications = self::array_attr($attributes, 'publications');
        $sections_title = self::string_attr($attributes, 'sectionsTitle', 'Разделы сайта');
        $sections_open = array_key_exists('sectionsOpen', $attributes) ? !empty($attributes['sectionsOpen']) : true;
        $sections = self::array_attr($attributes, 'sections');
        $rubrics_title = self::string_attr($attributes, 'rubricsTitle', 'Рубрики');
        $rubrics_open = array_key_exists('rubricsOpen', $attributes) ? !empty($attributes['rubricsOpen']) : true;
        $categories = self::array_attr($attributes, 'categories');

        ob_start();
        ?>
        <div class="stack">
            <div class="bento-card reveal is-in">
                <?php if ($currency_title !== '') : ?>
                    <h3 style="margin:6px 0 10px;"><?php echo esc_html($currency_title); ?></h3>
                <?php endif; ?>
                <?php if ($date_line !== '') : ?>
                    <div class="kicker"><?php echo esc_html($date_line); ?></div>
                <?php endif; ?>
                <?php if ($legend_title !== '' || $buy_label !== '' || $sell_label !== '') : ?>
                    <div class="fine" style="margin-top:8px;">
                        <?php if ($legend_title !== '') : ?><b><?php echo esc_html($legend_title); ?></b><?php endif; ?>
                        <?php if ($buy_label !== '' || $sell_label !== '') : ?>
                            <?php echo esc_html(trim(($buy_label !== '' ? $buy_label : '') . ' / ' . ($sell_label !== '' ? $sell_label : ''), ' /')); ?>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
                <div class="rates">
                    <?php foreach ($rates as $rate) :
                        if (!is_array($rate)) { continue; }
                        if (array_key_exists('visible', $rate) && empty($rate['visible'])) { continue; }
                        $code = isset($rate['code']) ? (string) $rate['code'] : '';
                        $buy = isset($rate['buy']) ? (string) $rate['buy'] : '';
                        $sell = isset($rate['sell']) ? (string) $rate['sell'] : '';
                        if ($code === '' && $buy === '' && $sell === '') { continue; }
                        ?>
                        <div class="rate-row">
                            <span class="mono"><?php echo esc_html($code); ?></span>
                            <span class="muted"><?php echo esc_html($buy_label); ?></span>
                            <span class="mono"><?php echo esc_html($buy); ?></span>
                            <span class="muted"><?php echo esc_html($sell_label); ?></span>
                            <span class="mono"><?php echo esc_html($sell); ?></span>
                        </div>
                    <?php endforeach; ?>
                </div>
                <?php if ($footer_text !== '') : ?>
                    <div class="fine" style="margin-top:8px;"><?php echo esc_html($footer_text); ?></div>
                <?php endif; ?>
            </div>
            <div class="bento-card reveal is-in">
                <?php if ($publications_kicker !== '') : ?>
                    <div class="kicker"><?php echo esc_html($publications_kicker); ?></div>
                <?php endif; ?>
                <?php if ($publications_title !== '') : ?>
                    <h3 style="margin:6px 0 10px;"><?php echo esc_html($publications_title); ?></h3>
                <?php endif; ?>
                <div class="posts">
                    <?php foreach ($publications as $publication) :
                        if (!is_array($publication)) { continue; }
                        $date = isset($publication['date']) ? (string) $publication['date'] : '';
                        $title = isset($publication['title']) ? (string) $publication['title'] : '';
                        $url = isset($publication['url']) ? (string) $publication['url'] : '';
                        $external = !empty($publication['external']);
                        if ($title === '' || $url === '') { continue; }
                        ?>
                        <a class="post" href="<?php echo esc_url($url); ?>"<?php echo $external ? ' target="_blank" rel="noopener"' : ''; ?>>
                            <?php if ($date !== '') : ?><span class="muted"><?php echo esc_html($date); ?></span><?php endif; ?>
                            <strong><?php echo esc_html($title); ?></strong>
                        </a>
                    <?php endforeach; ?>
                </div>
            </div>
            <details class="reveal"<?php echo $sections_open ? ' open' : ''; ?>>
                <summary style="cursor:pointer; font-weight:600;"><?php echo esc_html($sections_title); ?></summary>
                <div class="drawer-links" style="margin-top:10px;">
                    <?php foreach ($sections as $section) :
                        if (!is_array($section)) { continue; }
                        $label = isset($section['label']) ? (string) $section['label'] : '';
                        $url = isset($section['url']) ? (string) $section['url'] : '';
                        $external = !empty($section['external']);
                        if ($label === '' || $url === '') { continue; }
                        ?>
                        <a class="drawer-sub" href="<?php echo esc_url($url); ?>"<?php echo $external ? ' target="_blank" rel="noopener"' : ''; ?>><?php echo esc_html($label); ?></a>
                    <?php endforeach; ?>
                </div>
            </details>
            <details class="reveal"<?php echo $rubrics_open ? ' open' : ''; ?>>
                <summary style="cursor:pointer; font-weight:600;"><?php echo esc_html($rubrics_title); ?></summary>
                <div class="drawer-links" style="margin-top:10px;">
                    <?php foreach ($categories as $category) :
                        if (!is_array($category)) { continue; }
                        $label = isset($category['label']) ? (string) $category['label'] : '';
                        $url = isset($category['url']) ? (string) $category['url'] : '';
                        $external = !empty($category['external']);
                        if ($label === '' || $url === '') { continue; }
                        ?>
                        <a class="drawer-sub" href="<?php echo esc_url($url); ?>"<?php echo $external ? ' target="_blank" rel="noopener"' : ''; ?>><?php echo esc_html($label); ?></a>
                    <?php endforeach; ?>
                </div>
            </details>
        </div>
        <?php
        return trim((string) ob_get_clean());
    }

    public static function render_contact_channels(array $attributes): string {
        $items = self::array_attr($attributes, 'items');

        ob_start();
        ?>
        <div style="margin-top: var(--s-4);">
            <?php foreach ($items as $index => $item) :
                if (!is_array($item)) { continue; }
                $label = isset($item['label']) ? (string) $item['label'] : '';
                $value = isset($item['value']) ? (string) $item['value'] : '';
                $value_url = isset($item['valueUrl']) ? (string) $item['valueUrl'] : '';
                $description = isset($item['description']) ? (string) $item['description'] : '';
                $copy = isset($item['copyValue']) ? (string) $item['copyValue'] : $value;
                $actions = self::contact_actions_from_item($item);
                if ($label === '' && $value === '') { continue; }
                ?>
                <div>
                    <?php if ($label !== '') : ?><div class="kicker"><b><?php echo esc_html($label); ?></b></div><?php endif; ?>
                    <div>
                        <?php if ($value_url !== '') : ?>
                            <a href="<?php echo esc_url($value_url); ?>"><?php echo esc_html($value); ?></a>
                        <?php else : ?>
                            <?php echo esc_html($value); ?>
                        <?php endif; ?>
                    </div>
                    <?php if ($description !== '') : ?><div class="muted"><?php echo esc_html($description); ?></div><?php endif; ?>
                    <div class="kv-actions" style="margin-top:10px;">
                        <?php if ($copy !== '') : ?><button class="copy mini" type="button" data-copy="<?php echo esc_attr($copy); ?>">Копировать</button><?php endif; ?>
                        <?php foreach ($actions as $action) :
                            if (!is_array($action)) { continue; }
                            $action_text = isset($action['text']) ? (string) $action['text'] : '';
                            $action_url = isset($action['url']) ? (string) $action['url'] : '';
                            $variant = isset($action['variant']) ? (string) $action['variant'] : 'outline';
                            $btn_class = trim('btn ' . sanitize_html_class($variant));
                            if ($action_text === '' || $action_url === '') { continue; }
                            ?>
                            <a class="<?php echo esc_attr($btn_class); ?>" href="<?php echo esc_url($action_url); ?>"<?php echo self::new_tab_attrs($action); ?>><?php echo esc_html($action_text); ?></a>
                        <?php endforeach; ?>
                    </div>
                </div>
                <?php if ($index < count($items) - 1) : ?><hr><?php endif; ?>
            <?php endforeach; ?>
        </div>
        <?php
        return trim((string) ob_get_clean());
    }

    public static function render_contact_route_actions(array $attributes): string {
        $kicker = self::string_attr($attributes, 'kicker', '');
        $title = self::string_attr($attributes, 'title', '');
        $actions = self::contact_route_actions_from_attributes($attributes);

        ob_start();
        ?>
        <div style="margin-top: var(--s-4);">
            <div>
                <?php if ($kicker !== '') : ?><h3 class="kicker" style="text-align:center;"><?php echo esc_html($kicker); ?></h3><?php endif; ?>
                <?php if ($title !== '') : ?><h4 style="margin: 8px 0 10px;"><?php echo esc_html($title); ?></h4><?php endif; ?>
                <?php if (!empty($actions)) : ?>
                    <div class="row" style="margin-top:12px; flex-wrap:wrap;">
                        <?php foreach ($actions as $item) :
                            if (!is_array($item)) { continue; }
                            $item_text = isset($item['text']) ? (string) $item['text'] : '';
                            $item_url = isset($item['url']) ? (string) $item['url'] : '';
                            $variant = isset($item['variant']) ? (string) $item['variant'] : '';
                            $btn_class = trim('btn ' . sanitize_html_class($variant));
                            if ($item_text === '' || $item_url === '') { continue; }
                            ?>
                            <a class="<?php echo esc_attr($btn_class); ?>" href="<?php echo esc_url($item_url); ?>"<?php echo self::new_tab_attrs($item); ?>><?php echo esc_html($item_text); ?></a>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
            <div aria-hidden="true"></div>
        </div>
        <?php
        return trim((string) ob_get_clean());
    }
}

Slavyanbank_Editor_Blocks_Grouped_Stage1_7::init();
