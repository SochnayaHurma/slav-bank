<?php
/**
 * Plugin Name: Slavyanbank Editor Unified Hotfix 3
 * Description: Unified self-contained Slavyanbank editor plugin. Bundles editable blocks, repeaters, layout shells, and page patterns in one package.
 * Version: 1.0.2
 * Author: OpenAI
 */

if (!defined('ABSPATH')) {
    exit;
}

require_once __DIR__ . '/slavbank-editor-blocks-grouped-stage1.php';
require_once __DIR__ . '/slavbank-editor-patterns-stage1.php';
