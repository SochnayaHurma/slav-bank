(function (wp) {
    if (!wp || !wp.element || !wp.components || !wp.blockEditor) {
        return;
    }

    const el = wp.element.createElement;
    const InspectorControls = wp.blockEditor.InspectorControls;
    const useBlockProps = wp.blockEditor.useBlockProps;
    const PanelBody = wp.components.PanelBody;
    const TextControl = wp.components.TextControl;
    const TextareaControl = wp.components.TextareaControl;
    const ToggleControl = wp.components.ToggleControl;
    const SelectControl = wp.components.SelectControl;
    const Button = wp.components.Button;
    const BaseControl = wp.components.BaseControl;
    const Notice = wp.components.Notice;
    const ServerSideRender = (wp.serverSideRender && (wp.serverSideRender.default || wp.serverSideRender)) || null;

    function cloneItems(items) {
        return Array.isArray(items) ? items.map(function (item) {
            return Object.assign({}, item || {});
        }) : [];
    }

    function moveItem(items, fromIndex, toIndex) {
        if (!Array.isArray(items)) {
            return [];
        }

        if (toIndex < 0 || toIndex >= items.length || fromIndex === toIndex) {
            return cloneItems(items);
        }

        const next = cloneItems(items);
        const item = next.splice(fromIndex, 1)[0];
        next.splice(toIndex, 0, item);
        return next;
    }

    function itemHeading(label, item, index, titleField) {
        const raw = titleField && item && item[titleField] ? String(item[titleField]).trim() : '';
        return raw ? (label + ' #' + (index + 1) + ' — ' + raw) : (label + ' #' + (index + 1));
    }

    function Preview(props) {
        if (!ServerSideRender) {
            return el('div', { className: 'components-notice is-warning' }, 'ServerSideRender is unavailable.');
        }

        return el('div', { style: { marginTop: '12px' } }, el(ServerSideRender, {
            block: props.block,
            attributes: props.attributes,
            httpMethod: 'POST',
        }));
    }

    function blockShell(children) {
        return el('div', useBlockProps({ className: 'sbeb-stage1-block' }), children);
    }

    function renderField(field, items, index, onChange) {
        const item = items[index] || {};
        const commonProps = {
            key: field.key,
            label: field.label,
            value: item[field.key] === undefined || item[field.key] === null ? '' : item[field.key],
            onChange: function (value) {
                const next = cloneItems(items);
                next[index][field.key] = value;
                onChange(next);
            }
        };

        if (field.type === 'textarea') {
            return el(TextareaControl, Object.assign({}, commonProps, { rows: field.rows || 3 }));
        }

        if (field.type === 'toggle') {
            return el(ToggleControl, {
                key: field.key,
                label: field.label,
                checked: !!item[field.key],
                onChange: function (value) {
                    const next = cloneItems(items);
                    next[index][field.key] = value;
                    onChange(next);
                }
            });
        }

        if (field.type === 'select') {
            return el(SelectControl, Object.assign({}, commonProps, {
                options: Array.isArray(field.options) ? field.options : []
            }));
        }

        return el(TextControl, commonProps);
    }

    function ItemListEditor(props) {
        const items = Array.isArray(props.items) ? props.items : [];
        const label = props.label || 'Элементы';
        const addLabel = props.addLabel || 'Добавить элемент';
        const titleField = props.titleField || '';
        const defaults = props.defaults || {};
        const fields = Array.isArray(props.fields) ? props.fields : [];
        const onChange = typeof props.onChange === 'function' ? props.onChange : function () {};

        const rows = items.map(function (item, index) {
            item = item || {};
            return el('div', {
                key: label + '-' + index,
                style: {
                    border: '1px solid #dcdcde',
                    borderRadius: '8px',
                    padding: '12px',
                    marginBottom: '12px',
                    background: '#fff'
                }
            }, [
                el('div', {
                    key: 'head',
                    style: {
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'space-between',
                        gap: '8px',
                        marginBottom: '8px'
                    }
                }, [
                    el('div', {
                        key: 'title',
                        style: { fontWeight: 600, minWidth: 0 }
                    }, itemHeading(label, item, index, titleField)),
                    el('div', {
                        key: 'actions',
                        style: { display: 'flex', gap: '6px', flexWrap: 'wrap' }
                    }, [
                        el(Button, {
                            key: 'up',
                            variant: 'secondary',
                            disabled: index === 0,
                            onClick: function () {
                                onChange(moveItem(items, index, index - 1));
                            }
                        }, '↑ Вверх'),
                        el(Button, {
                            key: 'down',
                            variant: 'secondary',
                            disabled: index === items.length - 1,
                            onClick: function () {
                                onChange(moveItem(items, index, index + 1));
                            }
                        }, '↓ Вниз'),
                        el(Button, {
                            key: 'remove',
                            isDestructive: true,
                            variant: 'secondary',
                            onClick: function () {
                                const next = cloneItems(items);
                                next.splice(index, 1);
                                onChange(next);
                            }
                        }, 'Удалить')
                    ])
                ]),
                fields.map(function (field) {
                    return renderField(field, items, index, onChange);
                })
            ]);
        });

        rows.push(el(Button, {
            key: 'add',
            variant: 'primary',
            onClick: function () {
                const next = cloneItems(items);
                next.push(Object.assign({}, defaults));
                onChange(next);
            }
        }, addLabel));

        return el(BaseControl, { label: label }, rows);
    }

    window.SBEBStage1Common = {
        el: el,
        InspectorControls: InspectorControls,
        PanelBody: PanelBody,
        TextControl: TextControl,
        TextareaControl: TextareaControl,
        ToggleControl: ToggleControl,
        SelectControl: SelectControl,
        Button: Button,
        Notice: Notice,
        Preview: Preview,
        ItemListEditor: ItemListEditor,
        blockShell: blockShell,
        category: (window.SBEB_STAGE1_CONFIG && window.SBEB_STAGE1_CONFIG.category) || 'slavyanbank-stage1'
    };
})(window.wp);
