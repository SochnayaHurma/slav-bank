
(function (wp, common) {
    if (!wp || !wp.blocks || !wp.blockEditor || !wp.components || !common) {
        return;
    }

    const registerBlockType = wp.blocks.registerBlockType;
    const el = common.el;
    const category = common.category;
    const InspectorControls = common.InspectorControls;
    const PanelBody = common.PanelBody;
    const TextControl = common.TextControl;
    const SelectControl = common.SelectControl;
    const ToggleControl = common.ToggleControl;
    const InnerBlocks = wp.blockEditor.InnerBlocks;
    const useBlockProps = wp.blockEditor.useBlockProps;

    const SECTION_ALLOWED = [
        'slavyanbank-stage1/bento-layout',
        'slavyanbank-stage1/bento-card-shell',
        'slavyanbank-stage1/stack-shell',
        'slavyanbank-stage1/prose-shell',
        'slavyanbank-stage1/alert',
        'slavyanbank-stage1/document-shelf',
        'slavyanbank-stage1/document-rows',
        'slavyanbank-stage1/document-hero',
        'slavyanbank-stage1/tariff-card-list',
        'slavyanbank-stage1/document-tabs',
        'slavyanbank-stage1/requisites-table',
        'slavyanbank-stage1/support-topics-grid',
        'slavyanbank-stage1/service-links',
        'slavyanbank-stage1/reporting-accordion',
        'slavyanbank-stage1/home-stack',
        'slavyanbank-stage1/contact-channels',
        'slavyanbank-stage1/contact-route-actions',
        'core/paragraph',
        'core/heading',
        'core/list',
        'core/group',
        'core/html'
    ];

    const BENTO_ALLOWED = [
        'slavyanbank-stage1/bento-card-shell',
        'slavyanbank-stage1/stack-shell'
    ];

    const CARD_ALLOWED = [
        'slavyanbank-stage1/alert',
        'slavyanbank-stage1/document-shelf',
        'slavyanbank-stage1/document-rows',
        'slavyanbank-stage1/document-hero',
        'slavyanbank-stage1/tariff-card-list',
        'slavyanbank-stage1/document-tabs',
        'slavyanbank-stage1/requisites-table',
        'slavyanbank-stage1/support-topics-grid',
        'slavyanbank-stage1/service-links',
        'slavyanbank-stage1/reporting-accordion',
        'slavyanbank-stage1/contact-channels',
        'slavyanbank-stage1/contact-route-actions',
        'slavyanbank-stage1/home-stack',
        'slavyanbank-stage1/prose-shell',
        'core/paragraph',
        'core/heading',
        'core/list',
        'core/group',
        'core/html'
    ];

    const STACK_ALLOWED = [
        'slavyanbank-stage1/home-stack',
        'slavyanbank-stage1/service-links',
        'slavyanbank-stage1/support-topics-grid',
        'slavyanbank-stage1/document-shelf',
        'slavyanbank-stage1/document-rows',
        'slavyanbank-stage1/document-hero',
        'core/paragraph',
        'core/heading',
        'core/group',
        'core/html'
    ];

    registerBlockType('slavyanbank-stage1/section-shell', {
        apiVersion: 2,
        title: 'SB Section Shell',
        icon: 'layout',
        category: category,
        attributes: {
            variant: { type: 'string', default: 'default' },
            anchor: { type: 'string', default: '' }
        },
        edit: function (props) {
            const attributes = props.attributes;
            const setAttributes = props.setAttributes;
            const sectionClass = attributes.variant === 'dashv2' ? 'block dashv2' : 'block';
            const inner = el(InnerBlocks, {
                allowedBlocks: SECTION_ALLOWED,
                renderAppender: InnerBlocks.ButtonBlockAppender
            });

            return el('div', useBlockProps({ className: 'sbeb-stage1-layout-block' }), [
                el(InspectorControls, { key: 'inspector' },
                    el(PanelBody, { title: 'Контейнер секции', initialOpen: true }, [
                        el(SelectControl, {
                            key: 'variant',
                            label: 'Вариант секции',
                            value: attributes.variant,
                            options: [
                                { label: 'Обычная секция', value: 'default' },
                                { label: 'dashv2 секция', value: 'dashv2' }
                            ],
                            onChange: function (value) { setAttributes({ variant: value }); }
                        }),
                        el(TextControl, {
                            key: 'anchor',
                            label: 'id / anchor',
                            value: attributes.anchor || '',
                            onChange: function (value) { setAttributes({ anchor: value }); }
                        })
                    ])
                ),
                el('section', {
                    key: 'preview',
                    className: sectionClass,
                    id: attributes.anchor || undefined,
                    style: { outline: '1px dashed #dcdcde' }
                }, el('div', { className: 'container' }, inner))
            ]);
        },
        save: function (props) {
            const attributes = props.attributes || {};
            const sectionClass = attributes.variant === 'dashv2' ? 'block dashv2' : 'block';
            return el('section', {
                className: sectionClass,
                id: attributes.anchor || undefined
            }, el('div', { className: 'container' }, el(InnerBlocks.Content)));
        }
    });

    registerBlockType('slavyanbank-stage1/bento-layout', {
        apiVersion: 2,
        title: 'SB Bento Layout',
        icon: 'columns',
        category: category,
        edit: function () {
            return el('div', useBlockProps({ className: 'sbeb-stage1-layout-block' }),
                el('div', { className: 'bento', style: { outline: '1px dashed #dcdcde' } },
                    el(InnerBlocks, {
                        allowedBlocks: BENTO_ALLOWED,
                        template: [
                            ['slavyanbank-stage1/bento-card-shell'],
                            ['slavyanbank-stage1/stack-shell']
                        ],
                        templateLock: false,
                        renderAppender: InnerBlocks.ButtonBlockAppender
                    })
                )
            );
        },
        save: function () {
            return el('div', { className: 'bento' }, el(InnerBlocks.Content));
        }
    });

    registerBlockType('slavyanbank-stage1/bento-card-shell', {
        apiVersion: 2,
        title: 'SB Bento Card Shell',
        icon: 'index-card',
        category: category,
        parent: ['slavyanbank-stage1/bento-layout'],
        attributes: {
            padding: { type: 'string', default: 'var(--s-4)' },
            positionRelative: { type: 'boolean', default: true }
        },
        edit: function (props) {
            const attributes = props.attributes;
            const setAttributes = props.setAttributes;
            const style = {
                padding: attributes.padding || 'var(--s-4)',
                position: attributes.positionRelative ? 'relative' : undefined,
                outline: '1px dashed #dcdcde'
            };
            return el('div', useBlockProps({ className: 'sbeb-stage1-layout-block' }), [
                el(InspectorControls, { key: 'inspector' },
                    el(PanelBody, { title: 'Bento card', initialOpen: true }, [
                        el(TextControl, {
                            key: 'padding',
                            label: 'Padding (CSS value)',
                            value: attributes.padding || '',
                            onChange: function (value) { setAttributes({ padding: value }); }
                        }),
                        el(ToggleControl, {
                            key: 'positionRelative',
                            label: 'position: relative',
                            checked: !!attributes.positionRelative,
                            onChange: function (value) { setAttributes({ positionRelative: value }); }
                        })
                    ])
                ),
                el('div', { key: 'preview', className: 'bento-card', style: style },
                    el(InnerBlocks, {
                        allowedBlocks: CARD_ALLOWED,
                        renderAppender: InnerBlocks.ButtonBlockAppender
                    })
                )
            ]);
        },
        save: function (props) {
            const attributes = props.attributes || {};
            const style = {
                padding: attributes.padding || 'var(--s-4)',
                position: attributes.positionRelative ? 'relative' : undefined
            };
            return el('div', { className: 'bento-card', style: style }, el(InnerBlocks.Content));
        }
    });

    registerBlockType('slavyanbank-stage1/stack-shell', {
        apiVersion: 2,
        title: 'SB Stack Shell',
        icon: 'screenoptions',
        category: category,
        parent: ['slavyanbank-stage1/bento-layout'],
        edit: function () {
            return el('div', useBlockProps({ className: 'sbeb-stage1-layout-block' }),
                el('div', { className: 'stack', style: { outline: '1px dashed #dcdcde' } },
                    el(InnerBlocks, {
                        allowedBlocks: STACK_ALLOWED,
                        renderAppender: InnerBlocks.ButtonBlockAppender
                    })
                )
            );
        },
        save: function () {
            return el('div', { className: 'stack' }, el(InnerBlocks.Content));
        }
    });

    registerBlockType('slavyanbank-stage1/prose-shell', {
        apiVersion: 2,
        title: 'SB Prose Shell',
        icon: 'editor-paragraph',
        category: category,
        edit: function () {
            return el('div', useBlockProps({ className: 'sbeb-stage1-layout-block' }),
                el('div', { className: 'prose', style: { outline: '1px dashed #dcdcde' } },
                    el('div', { className: 'entry-content' },
                        el(InnerBlocks, {
                            allowedBlocks: [
                                'core/paragraph',
                                'core/heading',
                                'core/list',
                                'core/table',
                                'core/html',
                                'slavyanbank-stage1/document-shelf',
                                'slavyanbank-stage1/document-rows',
                                'slavyanbank-stage1/reporting-accordion'
                            ],
                            renderAppender: InnerBlocks.ButtonBlockAppender
                        })
                    )
                )
            );
        },
        save: function () {
            return el('div', { className: 'prose' }, el('div', { className: 'entry-content' }, el(InnerBlocks.Content)));
        }
    });
})(window.wp, window.SBEBStage1Common);
