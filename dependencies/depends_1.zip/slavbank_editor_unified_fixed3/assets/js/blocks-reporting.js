(function (wp, common) {
    if (!wp || !wp.blocks || !common) {
        return;
    }

    const registerBlockType = wp.blocks.registerBlockType;
    const SelectControl = wp.components.SelectControl;
    const Button = wp.components.Button;
    const useState = wp.element.useState;
    const el = common.el;
    const InspectorControls = common.InspectorControls;
    const PanelBody = common.PanelBody;
    const TextControl = common.TextControl;
    const TextareaControl = common.TextareaControl;
    const ToggleControl = common.ToggleControl;
    const ItemListEditor = common.ItemListEditor;
    const Preview = common.Preview;
    const blockShell = common.blockShell;
    const category = common.category;

    function deepClone(value) {
        return JSON.parse(JSON.stringify(value || []));
    }

    function sectionOptions(sections) {
        return (sections || []).map(function (section, index) {
            const label = section && section.summary ? String(section.summary) : ('Раздел #' + String(index + 1));
            return { label: label, value: String(index) };
        });
    }

    registerBlockType('slavyanbank-stage1/reporting-accordion', {
        apiVersion: 2,
        title: 'SB Reporting Accordion',
        icon: 'excerpt-view',
        category: category,
        attributes: {
            title: { type: 'string', default: 'ПРОМЕЖУТОЧНАЯ БУХГАЛТЕРСКАЯ (ФИНАНСОВАЯ) ОТЧЕТНОСТЬ,' },
            subtitle: { type: 'string', default: 'ПОКАЗАТЕЛИ ДЕЯТЕЛЬНОСТИ БАНКА' },
            sections: { type: 'array', default: [] }
        },
        edit: function (props) {
            const attributes = props.attributes;
            const setAttributes = props.setAttributes;
            const sections = Array.isArray(attributes.sections) ? attributes.sections : [];
            const options = sectionOptions(sections);
            const [selectedIndexState, setSelectedIndexState] = useState(0);
            const selectedIndex = Math.min(Math.max(selectedIndexState, 0), Math.max(sections.length - 1, 0));
            const selected = sections[selectedIndex] ? Object.assign({}, sections[selectedIndex]) : null;

            function setSections(next) {
                setAttributes({ sections: next });
                if (selectedIndex >= next.length && next.length > 0) {
                    setSelectedIndexState(next.length - 1);
                }
                if (!next.length) {
                    setSelectedIndexState(0);
                }
            }

            function addSection() {
                const next = deepClone(sections);
                next.push({
                    summary: 'Новый раздел отчетности',
                    open: true,
                    entries: [
                        { title: 'Новый документ', note: '', url: '', newTab: true }
                    ]
                });
                setSections(next);
                setSelectedIndexState(next.length - 1);
            }

            function removeSection() {
                if (!selected) {
                    return;
                }
                const next = deepClone(sections);
                next.splice(selectedIndex, 1);
                setSections(next);
            }

            function moveSection(direction) {
                if (!selected) {
                    return;
                }
                const target = selectedIndex + direction;
                if (target < 0 || target >= sections.length) {
                    return;
                }
                const next = deepClone(sections);
                const item = next.splice(selectedIndex, 1)[0];
                next.splice(target, 0, item);
                setSections(next);
                setSelectedIndexState(target);
            }

            function updateSelected(updater) {
                if (!selected) {
                    return;
                }
                const next = deepClone(sections);
                next[selectedIndex] = updater(Object.assign({}, next[selectedIndex] || {}));
                setSections(next);
            }

            return blockShell([
                el(InspectorControls, { key: 'inspector' }, [
                    el(PanelBody, { key: 'base', title: 'Заголовки', initialOpen: true }, [
                        el(TextControl, {
                            key: 'title',
                            label: 'Верхний заголовок',
                            value: attributes.title,
                            onChange: function (value) { setAttributes({ title: value }); }
                        }),
                        el(TextControl, {
                            key: 'subtitle',
                            label: 'Нижний заголовок',
                            value: attributes.subtitle,
                            onChange: function (value) { setAttributes({ subtitle: value }); }
                        })
                    ]),
                    el(PanelBody, { key: 'sections', title: 'Разделы аккордеона', initialOpen: true }, [
                        options.length ? el(SelectControl, {
                            key: 'selectedSection',
                            label: 'Редактируемый раздел',
                            value: String(selectedIndex),
                            options: options,
                            onChange: function (value) { setSelectedIndexState(parseInt(value, 10) || 0); }
                        }) : el('p', { key: 'empty' }, 'Пока нет разделов.'),
                        el('div', {
                            key: 'actions',
                            style: { display: 'flex', gap: '8px', flexWrap: 'wrap', marginTop: '8px', marginBottom: '8px' }
                        }, [
                            el(Button, { key: 'add', variant: 'primary', onClick: addSection }, 'Добавить раздел'),
                            el(Button, { key: 'up', variant: 'secondary', disabled: !selected || selectedIndex === 0, onClick: function () { moveSection(-1); } }, '↑ Вверх'),
                            el(Button, { key: 'down', variant: 'secondary', disabled: !selected || selectedIndex === sections.length - 1, onClick: function () { moveSection(1); } }, '↓ Вниз'),
                            el(Button, { key: 'remove', variant: 'secondary', isDestructive: true, disabled: !selected, onClick: removeSection }, 'Удалить')
                        ]),
                        selected ? el('div', { key: 'selectedFields' }, [
                            el(TextControl, {
                                key: 'summary',
                                label: 'Заголовок раздела',
                                value: selected.summary || '',
                                onChange: function (value) {
                                    updateSelected(function (section) {
                                        section.summary = value;
                                        return section;
                                    });
                                }
                            }),
                            el(ToggleControl, {
                                key: 'open',
                                label: 'Открыт по умолчанию',
                                checked: !!selected.open,
                                onChange: function (value) {
                                    updateSelected(function (section) {
                                        section.open = value;
                                        return section;
                                    });
                                }
                            })
                        ]) : null
                    ]),
                    selected ? el(PanelBody, { key: 'entries', title: 'Документы выбранного раздела', initialOpen: false },
                        el(ItemListEditor, {
                            label: 'Документ',
                            addLabel: 'Добавить документ',
                            titleField: 'title',
                            items: Array.isArray(selected.entries) ? selected.entries : [],
                            onChange: function (items) {
                                updateSelected(function (section) {
                                    section.entries = items;
                                    return section;
                                });
                            },
                            defaults: { title: 'Новый документ', note: '', url: '', newTab: true },
                            fields: [
                                { key: 'title', label: 'Заголовок' },
                                { key: 'note', label: 'Подпись / дата', type: 'textarea', rows: 2 },
                                { key: 'url', label: 'URL' },
                                { key: 'newTab', label: 'Открывать в новой вкладке', type: 'toggle' }
                            ]
                        })
                    ) : null
                ]),
                el(Preview, { key: 'preview', block: 'slavyanbank-stage1/reporting-accordion', attributes: attributes })
            ]);
        },
        save: function () { return null; }
    });
})(window.wp, window.SBEBStage1Common);
