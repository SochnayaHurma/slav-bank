(function (wp, common) {
    if (!wp || !wp.blocks || !common) {
        return;
    }

    const registerBlockType = wp.blocks.registerBlockType;
    const el = common.el;
    const InspectorControls = common.InspectorControls;
    const PanelBody = common.PanelBody;
    const TextControl = common.TextControl;
    const TextareaControl = common.TextareaControl;
    const Notice = common.Notice;
    const ItemListEditor = common.ItemListEditor;
    const Preview = common.Preview;
    const blockShell = common.blockShell;
    const category = common.category;

    const buttonVariantOptions = [
        { label: 'Обычная .btn', value: '' },
        { label: 'Primary', value: 'primary' },
        { label: 'Outline', value: 'outline' },
        { label: 'Glass', value: 'glass' },
        { label: 'Soft', value: 'soft' },
        { label: 'Ghost', value: 'ghost' }
    ];

    const pillClassOptions = [
        { label: 'Badge mono', value: 'mono badge' },
        { label: 'Mono', value: 'mono' },
        { label: 'Badge', value: 'badge' },
        { label: 'Без класса', value: '' }
    ];

    function legacyActions(attributes) {
        const items = [];
        if (attributes.primaryButtonText || attributes.primaryButtonUrl) {
            items.push({ text: attributes.primaryButtonText || 'Кнопка', url: attributes.primaryButtonUrl || '', variant: 'primary', newTab: false });
        }
        if (attributes.secondaryButtonText || attributes.secondaryButtonUrl) {
            items.push({ text: attributes.secondaryButtonText || 'Кнопка', url: attributes.secondaryButtonUrl || '', variant: 'outline', newTab: false });
        }
        return items;
    }

    function legacyMetaItems(attributes) {
        const items = [];
        if (attributes.badge1Text || attributes.badge1Url) {
            items.push({ text: attributes.badge1Text || 'Пункт', url: attributes.badge1Url || '', className: 'mono badge', newTab: false });
        }
        if (attributes.badge2Text || attributes.badge2Url) {
            items.push({ text: attributes.badge2Text || 'Пункт', url: attributes.badge2Url || '', className: 'mono badge', newTab: false });
        }
        return items;
    }

    registerBlockType('slavyanbank-stage1/alert', {
        apiVersion: 2,
        title: 'SB Alert',
        icon: 'warning',
        category: category,
        attributes: {
            title: { type: 'string', default: 'Контакты банка' },
            text: { type: 'string', default: 'Ниже — основные каналы связи, адрес и режим работы.' }
        },
        edit: function (props) {
            const attributes = props.attributes;
            const setAttributes = props.setAttributes;
            return blockShell([
                el(InspectorControls, { key: 'inspector' },
                    el(PanelBody, { title: 'Содержимое', initialOpen: true }, [
                        el(TextControl, { key: 'title', label: 'Заголовок', value: attributes.title, onChange: function (value) { setAttributes({ title: value }); } }),
                        el(TextareaControl, { key: 'text', label: 'Текст', rows: 4, value: attributes.text, onChange: function (value) { setAttributes({ text: value }); } })
                    ])
                ),
                el(Preview, { key: 'preview', block: 'slavyanbank-stage1/alert', attributes: attributes })
            ]);
        },
        save: function () { return null; }
    });

    registerBlockType('slavyanbank-stage1/hero-shell', {
        apiVersion: 2,
        title: 'SB Hero Shell',
        icon: 'cover-image',
        category: category,
        attributes: {
            kicker: { type: 'string', default: 'Информация банка' },
            title: { type: 'string', default: 'Отчетность' },
            text: { type: 'string', default: 'Бухгалтерская (финансовая) отчетность раскрывается в ограниченном объёме.' },
            actions: { type: 'array', default: [] },
            metaItems: { type: 'array', default: [] },
            primaryButtonText: { type: 'string', default: 'Содержание' },
            primaryButtonUrl: { type: 'string', default: '#content' },
            secondaryButtonText: { type: 'string', default: 'На главную' },
            secondaryButtonUrl: { type: 'string', default: '/' },
            badge1Text: { type: 'string', default: 'Реквизиты' },
            badge1Url: { type: 'string', default: '/rekvizity-banka/' },
            badge2Text: { type: 'string', default: 'Информация банка' },
            badge2Url: { type: 'string', default: '/informaciya-banka/' }
        },
        edit: function (props) {
            const attributes = props.attributes;
            const setAttributes = props.setAttributes;
            const actions = Array.isArray(attributes.actions) && attributes.actions.length ? attributes.actions : legacyActions(attributes);
            const metaItems = Array.isArray(attributes.metaItems) && attributes.metaItems.length ? attributes.metaItems : legacyMetaItems(attributes);
            return blockShell([
                el(InspectorControls, { key: 'inspector' },
                    el(PanelBody, { title: 'Hero', initialOpen: true }, [
                        el(TextControl, { key: 'kicker', label: 'Kicker', value: attributes.kicker, onChange: function (v) { setAttributes({ kicker: v }); } }),
                        el(TextControl, { key: 'title', label: 'Заголовок', value: attributes.title, onChange: function (v) { setAttributes({ title: v }); } }),
                        el(TextareaControl, { key: 'text', label: 'Текст', rows: 4, value: attributes.text, onChange: function (v) { setAttributes({ text: v }); } }),
                        el(ItemListEditor, {
                            key: 'actions',
                            label: 'Кнопка',
                            addLabel: 'Добавить кнопку',
                            titleField: 'text',
                            items: actions,
                            onChange: function (items) { setAttributes({ actions: items }); },
                            defaults: { text: 'Новая кнопка', url: '', variant: 'outline', newTab: false },
                            fields: [
                                { key: 'text', label: 'Текст' },
                                { key: 'url', label: 'href' },
                                { key: 'variant', label: 'Вариант .btn*', type: 'select', options: buttonVariantOptions },
                                { key: 'newTab', label: 'Открывать в новой вкладке', type: 'toggle' }
                            ]
                        }),
                        el(ItemListEditor, {
                            key: 'metaItems',
                            label: 'Элемент pill',
                            addLabel: 'Добавить элемент pill',
                            titleField: 'text',
                            items: metaItems,
                            onChange: function (items) { setAttributes({ metaItems: items }); },
                            defaults: { text: 'Новый элемент', url: '', className: 'mono badge', newTab: false },
                            fields: [
                                { key: 'text', label: 'Текст' },
                                { key: 'url', label: 'href (можно пусто)' },
                                { key: 'className', label: 'Классы элемента', type: 'select', options: pillClassOptions },
                                { key: 'newTab', label: 'Открывать в новой вкладке', type: 'toggle' }
                            ]
                        })
                    ])
                ),
                el(Notice, { key: 'note', status: 'info', isDismissible: false }, 'Hero переведён на повторители: можно задавать разное количество .row a.btn* и элементов в pill, а также редактировать href.'),
                el(Preview, { key: 'preview', block: 'slavyanbank-stage1/hero-shell', attributes: Object.assign({}, attributes, { actions: actions, metaItems: metaItems }) })
            ]);
        },
        save: function () { return null; }
    });
})(window.wp, window.SBEBStage1Common);
