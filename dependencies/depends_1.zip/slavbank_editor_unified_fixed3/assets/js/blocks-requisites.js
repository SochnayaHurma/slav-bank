(function (wp, common) {
    if (!wp || !wp.blocks || !common) {
        return;
    }

    const registerBlockType = wp.blocks.registerBlockType;
    const el = common.el;
    const InspectorControls = common.InspectorControls;
    const PanelBody = common.PanelBody;
    const ItemListEditor = common.ItemListEditor;
    const Preview = common.Preview;
    const blockShell = common.blockShell;
    const category = common.category;

    registerBlockType('slavyanbank-stage1/requisites-table', {
        apiVersion: 2,
        title: 'SB Requisites Table',
        icon: 'table-col-before',
        category: category,
        attributes: {
            items: { type: 'array', default: [] }
        },
        edit: function (props) {
            const attributes = props.attributes;
            const setAttributes = props.setAttributes;
            return blockShell([
                el(InspectorControls, { key: 'inspector' },
                    el(PanelBody, { title: 'Реквизиты', initialOpen: true },
                        el(ItemListEditor, {
                            label: 'Строка реквизитов',
                            items: attributes.items,
                            onChange: function (items) { setAttributes({ items: items }); },
                            defaults: { label: '', value: '', copy: '', url: '', external: false },
                            fields: [
                                { key: 'label', label: 'Параметр', type: 'textarea' },
                                { key: 'value', label: 'Значение', type: 'textarea' },
                                { key: 'copy', label: 'Текст для копирования', type: 'textarea' },
                                { key: 'url', label: 'URL (необязательно)' },
                                { key: 'external', label: 'Открывать в новой вкладке', type: 'toggle' }
                            ]
                        })
                    )
                ),
                el(Preview, { key: 'preview', block: 'slavyanbank-stage1/requisites-table', attributes: attributes })
            ]);
        },
        save: function () { return null; }
    });
})(window.wp, window.SBEBStage1Common);
