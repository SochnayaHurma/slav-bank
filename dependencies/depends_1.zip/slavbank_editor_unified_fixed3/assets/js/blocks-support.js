(function (wp, common) {
    if (!wp || !wp.blocks || !common) {
        return;
    }

    const registerBlockType = wp.blocks.registerBlockType;
    const el = common.el;
    const InspectorControls = common.InspectorControls;
    const PanelBody = common.PanelBody;
    const ItemListEditor = common.ItemListEditor;
    const Preview = common.Preview;
    const blockShell = common.blockShell;
    const category = common.category;

    registerBlockType('slavyanbank-stage1/support-topics-grid', {
        apiVersion: 2,
        title: 'SB Support Topics Grid',
        icon: 'screenoptions',
        category: category,
        attributes: {
            items: { type: 'array', default: [] }
        },
        edit: function (props) {
            const attributes = props.attributes;
            const setAttributes = props.setAttributes;
            return blockShell([
                el(InspectorControls, { key: 'inspector' },
                    el(PanelBody, { title: 'Темы поддержки', initialOpen: true },
                        el(ItemListEditor, {
                            label: 'Тема',
                            addLabel: 'Добавить тему',
                            titleField: 'title',
                            items: attributes.items,
                            onChange: function (items) { setAttributes({ items: items }); },
                            defaults: { title: 'Новая тема', text: 'Открыть раздел →', url: '', newTab: false },
                            fields: [
                                { key: 'title', label: 'Заголовок' },
                                { key: 'text', label: 'Подпись' },
                                { key: 'url', label: 'URL' },
                                { key: 'newTab', label: 'Открывать в новой вкладке', type: 'toggle' }
                            ]
                        })
                    )
                ),
                el(Preview, { key: 'preview', block: 'slavyanbank-stage1/support-topics-grid', attributes: attributes })
            ]);
        },
        save: function () { return null; }
    });

    registerBlockType('slavyanbank-stage1/service-links', {
        apiVersion: 2,
        title: 'SB Service Links',
        icon: 'admin-links',
        category: category,
        attributes: {
            items: { type: 'array', default: [] }
        },
        edit: function (props) {
            const attributes = props.attributes;
            const setAttributes = props.setAttributes;
            return blockShell([
                el(InspectorControls, { key: 'inspector' },
                    el(PanelBody, { title: 'Сервисные ссылки', initialOpen: true },
                        el(ItemListEditor, {
                            label: 'Ссылка',
                            addLabel: 'Добавить ссылку',
                            titleField: 'title',
                            items: attributes.items,
                            onChange: function (items) { setAttributes({ items: items }); },
                            defaults: { title: 'Новая ссылка', url: '', ghost: false, newTab: false },
                            fields: [
                                { key: 'title', label: 'Текст' },
                                { key: 'url', label: 'URL' },
                                { key: 'ghost', label: 'Ghost style', type: 'toggle' },
                                { key: 'newTab', label: 'Открывать в новой вкладке', type: 'toggle' }
                            ]
                        })
                    )
                ),
                el(Preview, { key: 'preview', block: 'slavyanbank-stage1/service-links', attributes: attributes })
            ]);
        },
        save: function () { return null; }
    });
})(window.wp, window.SBEBStage1Common);
