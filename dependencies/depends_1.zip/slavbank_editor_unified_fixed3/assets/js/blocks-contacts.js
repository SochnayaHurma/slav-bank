(function (wp, common) {
    if (!wp || !wp.blocks || !common) {
        return;
    }

    const registerBlockType = wp.blocks.registerBlockType;
    const el = common.el;
    const InspectorControls = common.InspectorControls;
    const useState = wp.element.useState;
    const PanelBody = common.PanelBody;
    const TextControl = common.TextControl;
    const SelectControl = common.SelectControl;
    const ItemListEditor = common.ItemListEditor;
    const Preview = common.Preview;
    const blockShell = common.blockShell;
    const category = common.category;

    const buttonVariantOptions = [
        { label: 'Primary', value: 'primary' },
        { label: 'Outline', value: 'outline' },
        { label: 'Glass', value: 'glass' },
        { label: 'Soft', value: 'soft' },
        { label: 'Ghost', value: 'ghost' },
        { label: 'Обычная .btn', value: '' }
    ];

    function deepClone(value) {
        return JSON.parse(JSON.stringify(value || []));
    }

    function legacyRouteActions(attributes) {
        const items = [];
        if (attributes.primaryButtonText || attributes.primaryButtonUrl) {
            items.push({ text: attributes.primaryButtonText || 'Кнопка', url: attributes.primaryButtonUrl || '', variant: 'primary', newTab: true });
        }
        if (attributes.secondaryButtonText || attributes.secondaryButtonUrl) {
            items.push({ text: attributes.secondaryButtonText || 'Кнопка', url: attributes.secondaryButtonUrl || '', variant: 'outline', newTab: true });
        }
        return items;
    }

    function contactItemActions(item) {
        const actions = Array.isArray(item && item.actions) ? item.actions.filter(function (action) {
            return action && (action.text || action.url);
        }) : [];
        if (actions.length) {
            return actions;
        }

        const legacy = [];
        if (item && (item.action1Text || item.action1Url)) {
            legacy.push({ text: item.action1Text || 'Действие', url: item.action1Url || '', variant: 'outline', newTab: false });
        }
        if (item && (item.action2Text || item.action2Url)) {
            legacy.push({ text: item.action2Text || 'Действие', url: item.action2Url || '', variant: 'outline', newTab: true });
        }
        return legacy;
    }

    function normalizeContactItems(items) {
        return (Array.isArray(items) ? items : []).map(function (item) {
            const next = Object.assign({}, item || {});
            next.actions = contactItemActions(next);
            return next;
        });
    }

    function channelOptions(items) {
        return (items || []).map(function (item, index) {
            const label = item && item.label ? String(item.label) : ('Канал #' + String(index + 1));
            return { label: label, value: String(index) };
        });
    }

    registerBlockType('slavyanbank-stage1/contact-channels', {
        apiVersion: 2,
        title: 'SB Contact Channels',
        icon: 'phone',
        category: category,
        attributes: {
            items: { type: 'array', default: [] }
        },
        edit: function (props) {
            const attributes = props.attributes;
            const setAttributes = props.setAttributes;
            const items = normalizeContactItems(attributes.items);
            const options = channelOptions(items);
            const [selectedIndexState, setSelectedIndexState] = useState(0);
            const currentIndex = Math.min(Math.max(selectedIndexState, 0), Math.max(items.length - 1, 0));
            const currentItem = items[currentIndex] || null;

            function setItems(nextItems) {
                setAttributes({ items: nextItems });
                if (currentIndex >= nextItems.length && nextItems.length > 0) {
                    setSelectedIndexState(nextItems.length - 1);
                }
                if (!nextItems.length) {
                    setSelectedIndexState(0);
                }
            }

            function updateCurrentActions(nextActions) {
                if (!currentItem) {
                    return;
                }
                const nextItems = deepClone(items);
                nextItems[currentIndex].actions = nextActions;
                setItems(nextItems);
            }

            return blockShell([
                el(InspectorControls, { key: 'inspector' }, [
                    el(PanelBody, { key: 'channels', title: 'Каналы связи', initialOpen: true },
                        el(ItemListEditor, {
                            label: 'Канал',
                            addLabel: 'Добавить канал',
                            titleField: 'label',
                            items: items,
                            onChange: setItems,
                            defaults: {
                                label: 'Новый канал',
                                value: '',
                                valueUrl: '',
                                description: '',
                                copyValue: '',
                                actions: []
                            },
                            fields: [
                                { key: 'label', label: 'Заголовок' },
                                { key: 'value', label: 'Значение' },
                                { key: 'valueUrl', label: 'href значения' },
                                { key: 'description', label: 'Описание', type: 'textarea', rows: 2 },
                                { key: 'copyValue', label: 'Текст для копирования' }
                            ]
                        })
                    ),
                    currentItem ? el(PanelBody, { key: 'channel-actions', title: 'Действия выбранного канала', initialOpen: false }, [
                        options.length ? el(SelectControl, {
                            key: 'selectedChannel',
                            label: 'Редактируемый канал',
                            value: String(currentIndex),
                            options: options,
                            onChange: function (value) {
                                setSelectedIndexState(parseInt(value, 10) || 0);
                            }
                        }) : null,
                        el(ItemListEditor, {
                            key: 'nestedActions',
                            label: 'Действие',
                            addLabel: 'Добавить действие',
                            titleField: 'text',
                            items: Array.isArray(currentItem.actions) ? currentItem.actions : [],
                            onChange: updateCurrentActions,
                            defaults: { text: 'Новое действие', url: '', variant: 'outline', newTab: false },
                            fields: [
                                { key: 'text', label: 'Текст' },
                                { key: 'url', label: 'href' },
                                { key: 'variant', label: 'Вариант .btn*', type: 'select', options: buttonVariantOptions },
                                { key: 'newTab', label: 'Открывать в новой вкладке', type: 'toggle' }
                            ]
                        })
                    ]) : null
                ]),
                el(Preview, { key: 'preview', block: 'slavyanbank-stage1/contact-channels', attributes: Object.assign({}, attributes, { items: items }) })
            ]);
        },
        save: function () { return null; }
    });

    registerBlockType('slavyanbank-stage1/contact-route-actions', {
        apiVersion: 2,
        title: 'SB Contact Route Actions',
        icon: 'location-alt',
        category: category,
        attributes: {
            kicker: { type: 'string', default: 'Как нас найти' },
            title: { type: 'string', default: 'г. Великий Новгород, ул. Черемнова-Конюхова, дом 12' },
            actions: { type: 'array', default: [] },
            primaryButtonText: { type: 'string', default: 'Маршрут в Яндекс Картах →' },
            primaryButtonUrl: { type: 'string', default: '' },
            secondaryButtonText: { type: 'string', default: 'Маршрут в Google Maps →' },
            secondaryButtonUrl: { type: 'string', default: '' }
        },
        edit: function (props) {
            const attributes = props.attributes;
            const setAttributes = props.setAttributes;
            const actions = Array.isArray(attributes.actions) && attributes.actions.length ? attributes.actions : legacyRouteActions(attributes);
            return blockShell([
                el(InspectorControls, { key: 'inspector' },
                    el(PanelBody, { title: 'Маршруты', initialOpen: true }, [
                        el(TextControl, { key: 'kicker', label: 'Kicker', value: attributes.kicker, onChange: function (value) { setAttributes({ kicker: value }); } }),
                        el(TextControl, { key: 'title', label: 'Заголовок', value: attributes.title, onChange: function (value) { setAttributes({ title: value }); } }),
                        el(ItemListEditor, {
                            key: 'actions',
                            label: 'Кнопка маршрута',
                            addLabel: 'Добавить кнопку маршрута',
                            titleField: 'text',
                            items: actions,
                            onChange: function (items) { setAttributes({ actions: items }); },
                            defaults: { text: 'Новая кнопка', url: '', variant: 'outline', newTab: true },
                            fields: [
                                { key: 'text', label: 'Текст' },
                                { key: 'url', label: 'href' },
                                { key: 'variant', label: 'Вариант .btn*', type: 'select', options: buttonVariantOptions },
                                { key: 'newTab', label: 'Открывать в новой вкладке', type: 'toggle' }
                            ]
                        })
                    ])
                ),
                el(Preview, { key: 'preview', block: 'slavyanbank-stage1/contact-route-actions', attributes: Object.assign({}, attributes, { actions: actions }) })
            ]);
        },
        save: function () { return null; }
    });
})(window.wp, window.SBEBStage1Common);
