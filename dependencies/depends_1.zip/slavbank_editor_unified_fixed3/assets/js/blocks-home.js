(function (wp, common) {
    if (!wp || !wp.blocks || !common) {
        return;
    }

    const registerBlockType = wp.blocks.registerBlockType;
    const el = common.el;
    const InspectorControls = common.InspectorControls;
    const PanelBody = common.PanelBody;
    const TextControl = common.TextControl;
    const ToggleControl = common.ToggleControl;
    const ItemListEditor = common.ItemListEditor;
    const Preview = common.Preview;
    const blockShell = common.blockShell;
    const category = common.category;

    registerBlockType('slavyanbank-stage1/home-stack', {
        apiVersion: 2,
        title: 'SB Home Stack',
        icon: 'screenoptions',
        category: category,
        attributes: {
            currencyTitle: { type: 'string', default: 'Курсы валют' },
            dateLine: { type: 'string', default: 'Данные на текущую дату' },
            legendTitle: { type: 'string', default: 'Наличные' },
            buyLabel: { type: 'string', default: 'Покупка' },
            sellLabel: { type: 'string', default: 'Продажа' },
            footerText: { type: 'string', default: 'Информация носит справочный характер.' },
            rates: { type: 'array', default: [] },
            publicationsTitle: { type: 'string', default: 'Последние публикации' },
            publicationsKicker: { type: 'string', default: 'Полезная информация' },
            publications: { type: 'array', default: [] },
            sectionsTitle: { type: 'string', default: 'Разделы сайта' },
            sectionsOpen: { type: 'boolean', default: true },
            sections: { type: 'array', default: [] },
            rubricsTitle: { type: 'string', default: 'Рубрики' },
            rubricsOpen: { type: 'boolean', default: true },
            categories: { type: 'array', default: [] }
        },
        edit: function (props) {
            const attributes = props.attributes;
            const setAttributes = props.setAttributes;
            return blockShell([
                el(InspectorControls, { key: 'inspector' }, [
                    el(PanelBody, { key: 'currency', title: 'Валютный виджет', initialOpen: true }, [
                        el(TextControl, {
                            key: 'currencyTitle',
                            label: 'Заголовок',
                            value: attributes.currencyTitle,
                            onChange: function (value) { setAttributes({ currencyTitle: value }); }
                        }),
                        el(TextControl, {
                            key: 'dateLine',
                            label: 'Строка даты',
                            value: attributes.dateLine,
                            onChange: function (value) { setAttributes({ dateLine: value }); }
                        }),
                        el(TextControl, {
                            key: 'legendTitle',
                            label: 'Легенда',
                            value: attributes.legendTitle,
                            onChange: function (value) { setAttributes({ legendTitle: value }); }
                        }),
                        el(TextControl, {
                            key: 'buyLabel',
                            label: 'Подпись покупки',
                            value: attributes.buyLabel,
                            onChange: function (value) { setAttributes({ buyLabel: value }); }
                        }),
                        el(TextControl, {
                            key: 'sellLabel',
                            label: 'Подпись продажи',
                            value: attributes.sellLabel,
                            onChange: function (value) { setAttributes({ sellLabel: value }); }
                        }),
                        el(TextControl, {
                            key: 'footerText',
                            label: 'Нижняя подпись',
                            value: attributes.footerText,
                            onChange: function (value) { setAttributes({ footerText: value }); }
                        }),
                        el(ItemListEditor, {
                            key: 'rates',
                            label: 'Курс',
                            addLabel: 'Добавить курс',
                            titleField: 'code',
                            items: attributes.rates,
                            onChange: function (items) { setAttributes({ rates: items }); },
                            defaults: { code: 'USD', buy: '', sell: '', visible: true },
                            fields: [
                                { key: 'code', label: 'Код' },
                                { key: 'buy', label: 'Покупка' },
                                { key: 'sell', label: 'Продажа' },
                                { key: 'visible', label: 'Показывать строку', type: 'toggle' }
                            ]
                        })
                    ]),
                    el(PanelBody, { key: 'posts', title: 'Публикации', initialOpen: false }, [
                        el(TextControl, {
                            key: 'publicationsKicker',
                            label: 'Kicker',
                            value: attributes.publicationsKicker,
                            onChange: function (value) { setAttributes({ publicationsKicker: value }); }
                        }),
                        el(TextControl, {
                            key: 'publicationsTitle',
                            label: 'Заголовок',
                            value: attributes.publicationsTitle,
                            onChange: function (value) { setAttributes({ publicationsTitle: value }); }
                        }),
                        el(ItemListEditor, {
                            key: 'publications',
                            label: 'Публикация',
                            addLabel: 'Добавить публикацию',
                            titleField: 'title',
                            items: attributes.publications,
                            onChange: function (items) { setAttributes({ publications: items }); },
                            defaults: { date: '', title: 'Новая публикация', url: '', external: false },
                            fields: [
                                { key: 'date', label: 'Дата' },
                                { key: 'title', label: 'Заголовок' },
                                { key: 'url', label: 'href' },
                                { key: 'external', label: 'Открывать в новой вкладке', type: 'toggle' }
                            ]
                        })
                    ]),
                    el(PanelBody, { key: 'sections', title: 'Разделы и рубрики', initialOpen: false }, [
                        el(TextControl, {
                            key: 'sectionsTitle',
                            label: 'Заголовок разделов',
                            value: attributes.sectionsTitle,
                            onChange: function (value) { setAttributes({ sectionsTitle: value }); }
                        }),
                        el(ToggleControl, {
                            key: 'sectionsOpen',
                            label: 'Разделы открыты по умолчанию',
                            checked: !!attributes.sectionsOpen,
                            onChange: function (value) { setAttributes({ sectionsOpen: value }); }
                        }),
                        el(ItemListEditor, {
                            key: 'sectionsList',
                            label: 'Раздел',
                            addLabel: 'Добавить раздел',
                            titleField: 'label',
                            items: attributes.sections,
                            onChange: function (items) { setAttributes({ sections: items }); },
                            defaults: { label: 'Новый раздел', url: '', external: false },
                            fields: [
                                { key: 'label', label: 'Текст' },
                                { key: 'url', label: 'href' },
                                { key: 'external', label: 'Открывать в новой вкладке', type: 'toggle' }
                            ]
                        }),
                        el(TextControl, {
                            key: 'rubricsTitle',
                            label: 'Заголовок рубрик',
                            value: attributes.rubricsTitle,
                            onChange: function (value) { setAttributes({ rubricsTitle: value }); }
                        }),
                        el(ToggleControl, {
                            key: 'rubricsOpen',
                            label: 'Рубрики открыты по умолчанию',
                            checked: !!attributes.rubricsOpen,
                            onChange: function (value) { setAttributes({ rubricsOpen: value }); }
                        }),
                        el(ItemListEditor, {
                            key: 'categories',
                            label: 'Рубрика',
                            addLabel: 'Добавить рубрику',
                            titleField: 'label',
                            items: attributes.categories,
                            onChange: function (items) { setAttributes({ categories: items }); },
                            defaults: { label: 'Новая рубрика', url: '', external: false },
                            fields: [
                                { key: 'label', label: 'Текст' },
                                { key: 'url', label: 'href' },
                                { key: 'external', label: 'Внешняя ссылка / новая вкладка', type: 'toggle' }
                            ]
                        })
                    ])
                ]),
                el(Preview, { key: 'preview', block: 'slavyanbank-stage1/home-stack', attributes: attributes })
            ]);
        },
        save: function () { return null; }
    });
})(window.wp, window.SBEBStage1Common);
