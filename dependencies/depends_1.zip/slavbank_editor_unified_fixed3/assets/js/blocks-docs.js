(function (wp, common) {
    if (!wp || !wp.blocks || !common) {
        return;
    }

    const registerBlockType = wp.blocks.registerBlockType;
    const SelectControl = wp.components.SelectControl;
    const Button = wp.components.Button;
    const el = common.el;
    const InspectorControls = common.InspectorControls;
    const PanelBody = common.PanelBody;
    const TextControl = common.TextControl;
    const TextareaControl = common.TextareaControl;
    const ToggleControl = common.ToggleControl;
    const ItemListEditor = common.ItemListEditor;
    const Preview = common.Preview;
    const blockShell = common.blockShell;
    const category = common.category;

    function deepClone(value) {
        return JSON.parse(JSON.stringify(value || []));
    }

    function updateTab(tabs, key, updater) {
        return tabs.map(function (tab) {
            if ((tab && tab.key) === key) {
                return updater(Object.assign({}, tab || {}));
            }
            return Object.assign({}, tab || {});
        });
    }

    function makeTabKey(index) {
        return 'tab-' + String(index + 1);
    }

    function tabOptions(tabs) {
        return (tabs || []).map(function (tab, index) {
            const key = tab && tab.key ? String(tab.key) : makeTabKey(index);
            const label = tab && tab.label ? String(tab.label) : ('Вкладка #' + String(index + 1));
            return { label: label, value: key };
        });
    }

    registerBlockType('slavyanbank-stage1/document-shelf', {
        apiVersion: 2,
        title: 'SB Document Shelf',
        icon: 'index-card',
        category: category,
        attributes: {
            items: { type: 'array', default: [] }
        },
        edit: function (props) {
            const attributes = props.attributes;
            const setAttributes = props.setAttributes;
            return blockShell([
                el(InspectorControls, { key: 'inspector' },
                    el(PanelBody, { title: 'Карточки документов', initialOpen: true },
                        el(ItemListEditor, {
                            label: 'Документ',
                            addLabel: 'Добавить документ',
                            titleField: 'title',
                            items: attributes.items,
                            onChange: function (items) { setAttributes({ items: items }); },
                            defaults: { title: 'Новый документ', footer: '', url: '', kind: 'PDF', newTab: true },
                            fields: [
                                { key: 'title', label: 'Заголовок' },
                                { key: 'footer', label: 'Подпись', type: 'textarea' },
                                { key: 'url', label: 'URL' },
                                { key: 'kind', label: 'Тип файла' },
                                { key: 'newTab', label: 'Открывать в новой вкладке', type: 'toggle' }
                            ]
                        })
                    )
                ),
                el(Preview, { key: 'preview', block: 'slavyanbank-stage1/document-shelf', attributes: attributes })
            ]);
        },
        save: function () { return null; }
    });

    registerBlockType('slavyanbank-stage1/document-rows', {
        apiVersion: 2,
        title: 'SB Document Rows',
        icon: 'list-view',
        category: category,
        attributes: {
            items: { type: 'array', default: [] }
        },
        edit: function (props) {
            const attributes = props.attributes;
            const setAttributes = props.setAttributes;
            return blockShell([
                el(InspectorControls, { key: 'inspector' },
                    el(PanelBody, { title: 'Строки документов', initialOpen: true },
                        el(ItemListEditor, {
                            label: 'Строка',
                            addLabel: 'Добавить строку',
                            titleField: 'title',
                            items: attributes.items,
                            onChange: function (items) { setAttributes({ items: items }); },
                            defaults: { date: '', title: 'Новый документ', url: '', kind: 'PDF', newTab: true },
                            fields: [
                                { key: 'date', label: 'Дата / метка' },
                                { key: 'title', label: 'Заголовок' },
                                { key: 'url', label: 'URL' },
                                { key: 'kind', label: 'Тип файла' },
                                { key: 'newTab', label: 'Открывать в новой вкладке', type: 'toggle' }
                            ]
                        })
                    )
                ),
                el(Preview, { key: 'preview', block: 'slavyanbank-stage1/document-rows', attributes: attributes })
            ]);
        },
        save: function () { return null; }
    });

    registerBlockType('slavyanbank-stage1/document-hero', {
        apiVersion: 2,
        title: 'SB Document Hero',
        icon: 'media-document',
        category: category,
        attributes: {
            title: { type: 'string', default: 'Список лиц, под контролем или значительным влиянием которых находится банк' },
            subtitle: { type: 'string', default: 'Скачать PDF' },
            url: { type: 'string', default: 'https://slavbank.ru/wp-content/uploads/2021/03/spisok250320.pdf' },
            newTab: { type: 'boolean', default: true }
        },
        edit: function (props) {
            const attributes = props.attributes;
            const setAttributes = props.setAttributes;
            return blockShell([
                el(InspectorControls, { key: 'inspector' },
                    el(PanelBody, { title: 'Документ', initialOpen: true }, [
                        el(TextControl, { key: 'title', label: 'Заголовок', value: attributes.title, onChange: function (v) { setAttributes({ title: v }); } }),
                        el(TextControl, { key: 'subtitle', label: 'Подзаголовок', value: attributes.subtitle, onChange: function (v) { setAttributes({ subtitle: v }); } }),
                        el(TextControl, { key: 'url', label: 'URL', value: attributes.url, onChange: function (v) { setAttributes({ url: v }); } }),
                        el(ToggleControl, { key: 'newTab', label: 'Открывать в новой вкладке', checked: !!attributes.newTab, onChange: function (v) { setAttributes({ newTab: v }); } })
                    ])
                ),
                el(Preview, { key: 'preview', block: 'slavyanbank-stage1/document-hero', attributes: attributes })
            ]);
        },
        save: function () { return null; }
    });

    registerBlockType('slavyanbank-stage1/tariff-card-list', {
        apiVersion: 2,
        title: 'SB Labeled Card List',
        icon: 'media-spreadsheet',
        category: category,
        attributes: {
            items: { type: 'array', default: [] }
        },
        edit: function (props) {
            const attributes = props.attributes;
            const setAttributes = props.setAttributes;
            return blockShell([
                el(InspectorControls, { key: 'inspector' },
                    el(PanelBody, { title: 'Карточки-ссылки', initialOpen: true },
                        el(ItemListEditor, {
                            label: 'Карточка',
                            addLabel: 'Добавить карточку',
                            titleField: 'title',
                            items: attributes.items,
                            onChange: function (items) { setAttributes({ items: items }); },
                            defaults: { date: '', title: 'Новая карточка', url: '', newTab: true },
                            fields: [
                                { key: 'date', label: 'Правая метка' },
                                { key: 'title', label: 'Заголовок' },
                                { key: 'url', label: 'URL' },
                                { key: 'newTab', label: 'Открывать в новой вкладке', type: 'toggle' }
                            ]
                        })
                    )
                ),
                el(Preview, { key: 'preview', block: 'slavyanbank-stage1/tariff-card-list', attributes: attributes })
            ]);
        },
        save: function () { return null; }
    });

    registerBlockType('slavyanbank-stage1/document-tabs', {
        apiVersion: 2,
        title: 'SB Tabbed Document Panels',
        icon: 'index-card',
        category: category,
        attributes: {
            ariaLabel: { type: 'string', default: 'Документы банка' },
            activeTab: { type: 'string', default: 'aff' },
            tabs: { type: 'array', default: [] }
        },
        edit: function (props) {
            const attributes = props.attributes;
            const setAttributes = props.setAttributes;
            const tabs = Array.isArray(attributes.tabs) ? attributes.tabs : [];
            const options = tabOptions(tabs);
            const selectedKey = attributes.activeTab || (options[0] && options[0].value) || '';
            const selectedIndex = tabs.findIndex(function (tab) { return (tab && tab.key) === selectedKey; });
            const selectedTab = selectedIndex >= 0 ? Object.assign({}, tabs[selectedIndex] || {}) : null;

            function setTabs(nextTabs, nextActiveKey) {
                const payload = { tabs: nextTabs };
                if (typeof nextActiveKey === 'string') {
                    payload.activeTab = nextActiveKey;
                }
                setAttributes(payload);
            }

            function addTab() {
                const next = deepClone(tabs);
                const key = makeTabKey(next.length);
                next.push({
                    key: key,
                    label: 'Новая вкладка',
                    intro: '',
                    panelType: 'rows',
                    rows: [
                        { date: '', title: 'Новый документ', url: '', kind: 'PDF', newTab: true }
                    ],
                    heroTitle: 'Новый документ',
                    heroSubtitle: 'Скачать PDF',
                    heroUrl: '',
                    heroNewTab: true
                });
                setTabs(next, key);
            }

            function removeCurrent() {
                if (selectedIndex < 0) {
                    return;
                }
                const next = deepClone(tabs);
                next.splice(selectedIndex, 1);
                const newActive = next[selectedIndex] ? next[selectedIndex].key : (next[selectedIndex - 1] ? next[selectedIndex - 1].key : '');
                setTabs(next, newActive);
            }

            function moveCurrent(direction) {
                if (selectedIndex < 0) {
                    return;
                }
                const target = selectedIndex + direction;
                if (target < 0 || target >= tabs.length) {
                    return;
                }
                const next = deepClone(tabs);
                const item = next.splice(selectedIndex, 1)[0];
                next.splice(target, 0, item);
                setTabs(next, item.key || selectedKey);
            }

            function updateSelected(updater) {
                if (!selectedTab) {
                    return;
                }
                const next = updateTab(tabs, selectedKey, updater);
                setTabs(next, selectedKey);
            }

            return blockShell([
                el(InspectorControls, { key: 'inspector' }, [
                    el(PanelBody, { key: 'base', title: 'Табы документов', initialOpen: true }, [
                        el(TextControl, {
                            key: 'ariaLabel',
                            label: 'ARIA label',
                            value: attributes.ariaLabel,
                            onChange: function (value) { setAttributes({ ariaLabel: value }); }
                        }),
                        options.length ? el(SelectControl, {
                            key: 'selectedTab',
                            label: 'Активная вкладка / редактируемая вкладка',
                            value: selectedKey,
                            options: options,
                            onChange: function (value) { setAttributes({ activeTab: value }); }
                        }) : el('p', { key: 'empty' }, 'Пока нет вкладок.'),
                        el('div', {
                            key: 'actions',
                            style: { display: 'flex', gap: '8px', flexWrap: 'wrap', marginTop: '8px', marginBottom: '8px' }
                        }, [
                            el(Button, { key: 'add', variant: 'primary', onClick: addTab }, 'Добавить вкладку'),
                            el(Button, { key: 'up', variant: 'secondary', disabled: selectedIndex <= 0, onClick: function () { moveCurrent(-1); } }, '↑ Вверх'),
                            el(Button, { key: 'down', variant: 'secondary', disabled: selectedIndex < 0 || selectedIndex === tabs.length - 1, onClick: function () { moveCurrent(1); } }, '↓ Вниз'),
                            el(Button, { key: 'remove', variant: 'secondary', isDestructive: true, disabled: selectedIndex < 0, onClick: removeCurrent }, 'Удалить')
                        ]),
                        selectedTab ? el('div', { key: 'selectedFields' }, [
                            el(TextControl, {
                                key: 'keyField',
                                label: 'Ключ вкладки',
                                value: selectedTab.key || '',
                                onChange: function (value) {
                                    const trimmed = String(value || '').trim();
                                    updateSelected(function (tab) {
                                        tab.key = trimmed;
                                        return tab;
                                    });
                                    if (trimmed) {
                                        setAttributes({ activeTab: trimmed });
                                    }
                                }
                            }),
                            el(TextControl, {
                                key: 'labelField',
                                label: 'Подпись вкладки',
                                value: selectedTab.label || '',
                                onChange: function (value) {
                                    updateSelected(function (tab) {
                                        tab.label = value;
                                        return tab;
                                    });
                                }
                            }),
                            el(TextareaControl, {
                                key: 'introField',
                                label: 'Вводный текст панели',
                                value: selectedTab.intro || '',
                                rows: 4,
                                onChange: function (value) {
                                    updateSelected(function (tab) {
                                        tab.intro = value;
                                        return tab;
                                    });
                                }
                            }),
                            el(SelectControl, {
                                key: 'panelType',
                                label: 'Тип содержимого панели',
                                value: selectedTab.panelType || 'rows',
                                options: [
                                    { label: 'Список документов', value: 'rows' },
                                    { label: 'Hero-документ', value: 'hero' }
                                ],
                                onChange: function (value) {
                                    updateSelected(function (tab) {
                                        tab.panelType = value;
                                        return tab;
                                    });
                                }
                            })
                        ]) : null
                    ]),
                    selectedTab && (selectedTab.panelType || 'rows') === 'rows'
                        ? el(PanelBody, { key: 'rowsPanel', title: 'Документы активной вкладки', initialOpen: false },
                            el(ItemListEditor, {
                                label: 'Документ',
                                addLabel: 'Добавить документ',
                                titleField: 'title',
                                items: Array.isArray(selectedTab.rows) ? selectedTab.rows : [],
                                onChange: function (items) {
                                    updateSelected(function (tab) {
                                        tab.rows = items;
                                        return tab;
                                    });
                                },
                                defaults: { date: '', title: 'Новый документ', url: '', kind: 'PDF', newTab: true },
                                fields: [
                                    { key: 'date', label: 'Дата / метка' },
                                    { key: 'title', label: 'Заголовок' },
                                    { key: 'url', label: 'URL' },
                                    { key: 'kind', label: 'Тип файла' },
                                    { key: 'newTab', label: 'Открывать в новой вкладке', type: 'toggle' }
                                ]
                            })
                        )
                        : null,
                    selectedTab && (selectedTab.panelType || 'rows') === 'hero'
                        ? el(PanelBody, { key: 'heroPanel', title: 'Hero-документ активной вкладки', initialOpen: false }, [
                            el(TextControl, {
                                key: 'heroTitle',
                                label: 'Заголовок',
                                value: selectedTab.heroTitle || '',
                                onChange: function (value) {
                                    updateSelected(function (tab) {
                                        tab.heroTitle = value;
                                        return tab;
                                    });
                                }
                            }),
                            el(TextControl, {
                                key: 'heroSubtitle',
                                label: 'Подзаголовок',
                                value: selectedTab.heroSubtitle || '',
                                onChange: function (value) {
                                    updateSelected(function (tab) {
                                        tab.heroSubtitle = value;
                                        return tab;
                                    });
                                }
                            }),
                            el(TextControl, {
                                key: 'heroUrl',
                                label: 'URL',
                                value: selectedTab.heroUrl || '',
                                onChange: function (value) {
                                    updateSelected(function (tab) {
                                        tab.heroUrl = value;
                                        return tab;
                                    });
                                }
                            }),
                            el(ToggleControl, {
                                key: 'heroNewTab',
                                label: 'Открывать в новой вкладке',
                                checked: selectedTab.heroNewTab === undefined ? true : !!selectedTab.heroNewTab,
                                onChange: function (value) {
                                    updateSelected(function (tab) {
                                        tab.heroNewTab = value;
                                        return tab;
                                    });
                                }
                            })
                        ])
                        : null
                ]),
                el(Preview, { key: 'preview', block: 'slavyanbank-stage1/document-tabs', attributes: attributes })
            ]);
        },
        save: function () { return null; }
    });
})(window.wp, window.SBEBStage1Common);
