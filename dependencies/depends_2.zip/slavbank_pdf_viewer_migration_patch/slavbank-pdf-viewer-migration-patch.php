<?php
/**
 * Plugin Name: Slavyanbank PDF Viewer Migration Patch
 * Description: Adds reusable PDF viewer block and prefilled tariff migration patterns using the existing theme PDF shell.
 * Version: 0.1.0
 * Author: OpenAI
 */

if (!defined('ABSPATH')) {
    exit;
}

final class Slavyanbank_PDF_Viewer_Migration_Patch {
    const HANDLE = 'slavbank-pdf-viewer-block';
    const BLOCK  = 'slavbank/pdf-viewer';

    public static function init(): void {
        add_action('init', [__CLASS__, 'register']);
    }

    public static function register(): void {
        wp_register_script(
            self::HANDLE,
            plugin_dir_url(__FILE__) . 'assets/js/pdf-viewer-block.js',
            ['wp-blocks', 'wp-block-editor', 'wp-components', 'wp-element', 'wp-i18n', 'wp-server-side-render'],
            '0.1.0',
            true
        );

        register_block_type(self::BLOCK, [
            'editor_script'   => self::HANDLE,
            'render_callback' => [__CLASS__, 'render_pdf_viewer'],
            'attributes'      => self::attributes_schema(),
        ]);

        register_block_pattern_category('slavyanbank-migration', [
            'label' => __('Slavyanbank Migration', 'slavyanbank-pdf-viewer-migration-patch'),
        ]);

        self::register_patterns();
    }

    private static function attributes_schema(): array {
        return [
            'kicker' => ['type' => 'string', 'default' => 'PDF-документ'],
            'title' => ['type' => 'string', 'default' => 'Документ'],
            'description' => ['type' => 'string', 'default' => 'Откройте внутри страницы или скачайте файл.'],
            'pdfUrl' => ['type' => 'string', 'default' => ''],
            'openLabel' => ['type' => 'string', 'default' => 'Открыть'],
            'downloadLabel' => ['type' => 'string', 'default' => 'Скачать'],
            'note' => ['type' => 'string', 'default' => 'Если PDF не отображается, используйте кнопку «Открыть».'],
            'showOpen' => ['type' => 'boolean', 'default' => true],
            'showDownload' => ['type' => 'boolean', 'default' => true],
        ];
    }

    public static function render_pdf_viewer(array $attributes = []): string {
        $attributes = wp_parse_args($attributes, [
            'kicker' => 'PDF-документ',
            'title' => 'Документ',
            'description' => 'Откройте внутри страницы или скачайте файл.',
            'pdfUrl' => '',
            'openLabel' => 'Открыть',
            'downloadLabel' => 'Скачать',
            'note' => 'Если PDF не отображается, используйте кнопку «Открыть».',
            'showOpen' => true,
            'showDownload' => true,
        ]);

        $pdf_url = trim((string) $attributes['pdfUrl']);
        if ($pdf_url === '') {
            return '<div class="pdf-shell"><div class="muted">PDF URL не задан.</div></div>';
        }

        $iframe_src = $pdf_url;
        if (strpos($iframe_src, '#') === false) {
            $iframe_src .= '#view=FitH';
        }

        ob_start();
        ?>
        <div class="pdf-shell">
            <div class="pdf-head">
                <div>
                    <div class="kicker"><?php echo esc_html((string) $attributes['kicker']); ?></div>
                    <div class="pdf-title"><?php echo esc_html((string) $attributes['title']); ?></div>
                    <?php if (trim((string) $attributes['description']) !== '') : ?>
                        <div class="muted" style="margin-top:6px;"><?php echo esc_html((string) $attributes['description']); ?></div>
                    <?php endif; ?>
                </div>
                <div class="pdf-actions">
                    <?php if (!empty($attributes['showOpen'])) : ?>
                        <a class="btn outline pill" href="<?php echo esc_url($pdf_url); ?>" target="_blank" rel="noopener">
                            <?php echo esc_html((string) $attributes['openLabel']); ?>
                        </a>
                    <?php endif; ?>
                    <?php if (!empty($attributes['showDownload'])) : ?>
                        <a class="btn glass pill" href="<?php echo esc_url($pdf_url); ?>" download>
                            <?php echo esc_html((string) $attributes['downloadLabel']); ?>
                        </a>
                    <?php endif; ?>
                </div>
            </div>
            <div class="pdf-frame">
                <iframe title="<?php echo esc_attr((string) $attributes['title']); ?>" src="<?php echo esc_url($iframe_src); ?>" loading="lazy"></iframe>
            </div>
            <?php if (trim((string) $attributes['note']) !== '') : ?>
                <div class="muted" style="margin-top:10px; font-weight:300;"><?php echo esc_html((string) $attributes['note']); ?></div>
            <?php endif; ?>
        </div>
        <?php
        return trim((string) ob_get_clean());
    }

    private static function register_patterns(): void {
        $patterns = [
            'tariffs-rf-pdf' => [
                'title' => 'SB Migration · Tariffs RF with PDF',
                'content' => self::build_tariff_pattern(
                    'Тарифы',
                    'Тарифы по операциям в валюте РФ',
                    'Тарифы банковских услуг по операциям в валюте РФ.',
                    'Тарифы по операциям в валюте РФ',
                    'https://slavbank.ru/wp-content/uploads/standard-osobiy-s-01012026.pdf'
                ),
            ],
            'tariffs-valuta-pdf' => [
                'title' => 'SB Migration · Tariffs Foreign Currency with PDF',
                'content' => self::build_tariff_pattern(
                    'Тарифы',
                    'Тарифы по операциям в иностранной валюте',
                    'Тарифы банковских услуг по обслуживанию операций в иностранной валюте.',
                    'Тарифы по операциям в иностранной валюте',
                    'https://slavbank.ru/wp-content/uploads/tarify-v-in-valyute-s-01122025.pdf'
                ),
            ],
            'tariff-slavny-pdf' => [
                'title' => 'SB Migration · Tariff Slavny with PDF',
                'content' => self::build_tariff_pattern(
                    'Тарифы',
                    'Тарифы «Славный»',
                    'Тарифы по операциям в рублях и иностранной валюте «Славный».',
                    'Тарифы «Славный»',
                    'https://slavbank.ru/wp-content/uploads/tp-slavny.pdf'
                ),
            ],
            'tariff-privetstvenny-pdf' => [
                'title' => 'SB Migration · Tariff Privetstvenny with PDF',
                'content' => self::build_tariff_pattern(
                    'Тарифы',
                    'Тарифы «Приветственный»',
                    'Тарифы по операциям в рублях и иностранной валюте «Приветственный».',
                    'Тарифы «Приветственный»',
                    'https://slavbank.ru/wp-content/uploads/tarif-privetstvenny.pdf'
                ),
            ],
            'tariff-depositny-pdf' => [
                'title' => 'SB Migration · Tariff Depositny with PDF',
                'content' => self::build_tariff_pattern(
                    'Тарифы',
                    'Тарифы «Депозитный»',
                    'Тарифы по операциям в рублях и иностранной валюте «Депозитный».',
                    'Тарифы «Депозитный»',
                    'https://slavbank.ru/wp-content/uploads/tarif-depositny.pdf'
                ),
            ],
        ];

        foreach ($patterns as $slug => $pattern) {
            register_block_pattern('slavyanbank-migration/' . $slug, [
                'title'      => __($pattern['title'], 'slavyanbank-pdf-viewer-migration-patch'),
                'categories' => ['slavyanbank-migration'],
                'content'    => $pattern['content'],
            ]);
        }
    }

    private static function build_tariff_pattern(string $kicker, string $title, string $lead, string $pdf_title, string $pdf_url): string {
        $json = wp_json_encode([
            'kicker' => 'PDF-документ',
            'title' => $pdf_title,
            'description' => 'Откройте внутри страницы или скачайте файл.',
            'pdfUrl' => $pdf_url,
            'openLabel' => 'Открыть',
            'downloadLabel' => 'Скачать',
            'note' => 'Если PDF не отображается, используйте кнопку «Открыть».',
            'showOpen' => true,
            'showDownload' => true,
        ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

        return implode("\n", [
            '<!-- wp:group {"className":"container"} -->',
            '<div class="wp-block-group container">',
            '<!-- wp:group {"className":"hero-wrap","style":{"spacing":{"padding":{"top":"24px","right":"24px","bottom":"24px","left":"24px"}}}} -->',
            '<div class="wp-block-group hero-wrap" style="padding-top:24px;padding-right:24px;padding-bottom:24px;padding-left:24px">',
            '<!-- wp:paragraph {"className":"kicker"} --><p class="kicker">' . esc_html($kicker) . '</p><!-- /wp:paragraph -->',
            '<!-- wp:heading {"level":1} --><h1>' . esc_html($title) . '</h1><!-- /wp:heading -->',
            '<!-- wp:paragraph {"className":"muted"} --><p class="muted">' . esc_html($lead) . '</p><!-- /wp:paragraph -->',
            '</div>',
            '<!-- /wp:group -->',
            '',
            '<!-- wp:group {"className":"pdf-shell"} -->',
            '<div class="wp-block-group pdf-shell">',
            '<!-- wp:' . self::BLOCK . ' ' . $json . ' /-->',
            '</div>',
            '<!-- /wp:group -->',
            '',
            '<!-- wp:group {"className":"prose"} -->',
            '<div class="wp-block-group prose">',
            '<!-- wp:paragraph {"className":"muted"} --><p class="muted">Замените legacy-наполнение этой страницы на migrated content в новом style-shell.</p><!-- /wp:paragraph -->',
            '</div>',
            '<!-- /wp:group -->',
            '</div>',
            '<!-- /wp:group -->',
        ]);
    }
}

Slavyanbank_PDF_Viewer_Migration_Patch::init();
