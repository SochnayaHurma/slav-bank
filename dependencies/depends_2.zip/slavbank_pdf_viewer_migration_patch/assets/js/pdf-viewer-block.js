(function (blocks, blockEditor, components, element, i18n, serverSideRender) {
  const el = element.createElement;
  const __ = i18n.__;
  const InspectorControls = blockEditor.InspectorControls;
  const useBlockProps = blockEditor.useBlockProps;
  const PanelBody = components.PanelBody;
  const TextControl = components.TextControl;
  const ToggleControl = components.ToggleControl;
  const ServerSideRender = serverSideRender;

  blocks.registerBlockType('slavbank/pdf-viewer', {
    title: __('SB PDF Viewer', 'slavyanbank-pdf-viewer-migration-patch'),
    icon: 'media-document',
    category: 'widgets',
    attributes: {
      kicker: { type: 'string', default: 'PDF-документ' },
      title: { type: 'string', default: 'Документ' },
      description: { type: 'string', default: 'Откройте внутри страницы или скачайте файл.' },
      pdfUrl: { type: 'string', default: '' },
      openLabel: { type: 'string', default: 'Открыть' },
      downloadLabel: { type: 'string', default: 'Скачать' },
      note: { type: 'string', default: 'Если PDF не отображается, используйте кнопку «Открыть».' },
      showOpen: { type: 'boolean', default: true },
      showDownload: { type: 'boolean', default: true }
    },
    edit: function (props) {
      const attrs = props.attributes;
      const set = props.setAttributes;
      return el(
        element.Fragment,
        null,
        el(
          InspectorControls,
          null,
          el(
            PanelBody,
            { title: __('PDF Viewer', 'slavyanbank-pdf-viewer-migration-patch'), initialOpen: true },
            el(TextControl, {
              label: __('Kicker', 'slavyanbank-pdf-viewer-migration-patch'),
              value: attrs.kicker,
              onChange: function (value) { set({ kicker: value }); }
            }),
            el(TextControl, {
              label: __('Title', 'slavyanbank-pdf-viewer-migration-patch'),
              value: attrs.title,
              onChange: function (value) { set({ title: value }); }
            }),
            el(TextControl, {
              label: __('Description', 'slavyanbank-pdf-viewer-migration-patch'),
              value: attrs.description,
              onChange: function (value) { set({ description: value }); }
            }),
            el(TextControl, {
              label: __('PDF URL', 'slavyanbank-pdf-viewer-migration-patch'),
              value: attrs.pdfUrl,
              onChange: function (value) { set({ pdfUrl: value }); }
            }),
            el(TextControl, {
              label: __('Open label', 'slavyanbank-pdf-viewer-migration-patch'),
              value: attrs.openLabel,
              onChange: function (value) { set({ openLabel: value }); }
            }),
            el(TextControl, {
              label: __('Download label', 'slavyanbank-pdf-viewer-migration-patch'),
              value: attrs.downloadLabel,
              onChange: function (value) { set({ downloadLabel: value }); }
            }),
            el(TextControl, {
              label: __('Note', 'slavyanbank-pdf-viewer-migration-patch'),
              value: attrs.note,
              onChange: function (value) { set({ note: value }); }
            }),
            el(ToggleControl, {
              label: __('Show open button', 'slavyanbank-pdf-viewer-migration-patch'),
              checked: !!attrs.showOpen,
              onChange: function (value) { set({ showOpen: !!value }); }
            }),
            el(ToggleControl, {
              label: __('Show download button', 'slavyanbank-pdf-viewer-migration-patch'),
              checked: !!attrs.showDownload,
              onChange: function (value) { set({ showDownload: !!value }); }
            })
          )
        ),
        el(
          'div',
          useBlockProps(),
          el(ServerSideRender, {
            block: 'slavbank/pdf-viewer',
            attributes: attrs,
            httpMethod: 'POST'
          })
        )
      );
    },
    save: function () { return null; }
  });
})(window.wp.blocks, window.wp.blockEditor, window.wp.components, window.wp.element, window.wp.i18n, window.wp.serverSideRender);
